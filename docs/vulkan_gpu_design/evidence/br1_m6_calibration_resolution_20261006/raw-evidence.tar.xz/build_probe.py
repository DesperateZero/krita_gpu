#!/usr/bin/env python3
"""Compile evidence probes using the current CPU target's real flags and libraries."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3] / "krita"
BUILD = ROOT / "_build-br0-cpu"
parser = argparse.ArgumentParser()
parser.add_argument("--arch", required=True, choices=["arm64", "x86_64"])
parser.add_argument("--source", default="joint-install-allocation-probe.cpp")
parser.add_argument("--name", default="install-probe")
parser.add_argument("--interpose", action="store_true")
parser.add_argument("--interposer-source", default="allocation-interposer.cpp")
args = parser.parse_args()
out = HERE / (args.name + "-" + args.arch)
out.mkdir()
record = next(row for row in json.loads((BUILD / "compile_commands.json").read_text())
    if row["file"].endswith("/KisPageStoreCpuMutationTest.cpp"))
command = shlex.split(record["command"])
flags, index = [], 0
while index < len(command):
    if command[index] in ["-o", "-c", "-arch"]:
        index += 2
    else:
        flags.append(command[index])
        index += 1
source = HERE / args.source
obj, binary = out / "probe.o", out / "probe"
section = (BUILD / "build.ninja").read_text().split("build bin/KisPageStoreCpuMutationTest:")[1].split("\n\n")[0]
libraries = shlex.split(re.search(r"^  LINK_LIBRARIES = (.*)$", section, re.M).group(1))
commands = []
interposer = []
if args.interpose:
    lib = out / "interposer.dylib"
    commands.append([command[0], "-std=c++17", "-dynamiclib", "-arch", args.arch,
        str(HERE / args.interposer_source), "-o", str(lib)])
    interposer.append(str(lib))
commands.append(flags + ["-arch", args.arch, "-c", str(source), "-o", str(obj)])
commands.append([command[0], "-arch", args.arch, str(obj), *interposer,
    "-o", str(binary), "-F" + str(ROOT / "_install/lib"), *libraries])
(out / "commands.json").write_text(json.dumps(commands, indent=2) + "\n")
for row in commands:
    subprocess.run(row, cwd=BUILD, check=True)
files = [source, Path(__file__), binary, BUILD / "bin/libkritaimage.21.0.0.dylib"]
if args.interpose:
    files.extend([HERE / args.interposer_source, lib])
identity = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
(out / "build-identity.json").write_text(json.dumps(identity, indent=2) + "\n")
print(str(binary), flush=True)
