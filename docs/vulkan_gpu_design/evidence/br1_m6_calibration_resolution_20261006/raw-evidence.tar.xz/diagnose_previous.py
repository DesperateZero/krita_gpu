"""Full retrospective tail diagnosis; never changes the previous qualification."""
from pathlib import Path
import hashlib
import json
import math
import statistics

H=Path(__file__).resolve().parent
P=H.parent/'br1_m6_provider_borrow_20261006'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((P/'calibration/runs.json').read_text())
assert len(rows)==1600
inputs={str(P/'calibration/runs.json'):sha(P/'calibration/runs.json'),
        str(P/'summary.json'):sha(P/'summary.json')}
items=[]
for r in rows:
    log=P/'calibration'/r['log'];inputs[str(log)]=sha(log)
    records=[json.loads(t.removeprefix('WINDOW ')) for t in log.read_text().splitlines() if t.startswith('WINDOW ')]
    assert len(records)==1 and len(records[0]['arms'])==1
    ns=records[0]['arms'][0]['operation_ns'];a=r['arms'][0]
    assert len(ns)==a['completed'] and sum(ns)==a['wall_ns']
    assert hashlib.sha256(json.dumps(ns).encode()).hexdigest()==a['operation_vector_sha256']
    ordered=sorted(ns);n=len(ns);median=statistics.median(ns);top=max(1,math.ceil(n*.01))
    items.append({'arch':r['arch'],'K':r['K'],'case':r['case'],'image':r['image'],'pair':r['pair'],
        'completed':n,'mean_ns':sum(ns)/n,'median_ns':median,'mean_over_median':sum(ns)/n/median,
        'p99_ns':ordered[min(n-1,int(n*.99))],'maximum_ns':ordered[-1],
        'top_1pct_wall_fraction':sum(ordered[-top:])/sum(ns),
        'over_2x_median_count':sum(t>2*median for t in ns),
        'over_2x_median_wall_fraction':sum(t for t in ns if t>2*median)/sum(ns)})
groups=[]
for arch in ['arm64','x86_64']:
    for k in [1,16]:
        for case in ['hit','single','native-pin','generic-lease','last-use']:
            g=[r for r in items if (r['arch'],r['K'],r['case'])==(arch,k,case)]
            logs={'throughput':[],'median_latency':[]}
            for pair in range(40):
                d={r['image']:r for r in g if r['pair']==pair};a,b=d['current'],d['selection']
                logs['throughput'].append(math.log(a['mean_ns']/b['mean_ns']))
                logs['median_latency'].append(math.log(a['median_ns']/b['median_ns']))
            groups.append({'arch':arch,'K':k,'case':case,
                'paired_log_throughput_sd':statistics.stdev(logs['throughput']),
                'paired_log_median_latency_sd':statistics.stdev(logs['median_latency']),
                'paired_median_latency_ratio':math.exp(statistics.median(logs['median_latency'])),
                'median_mean_over_median':statistics.median(r['mean_over_median'] for r in g),
                'median_top_1pct_wall_fraction':statistics.median(r['top_1pct_wall_fraction'] for r in g),
                'maximum_operation_ns':max(r['maximum_ns'] for r in g),
                'maximum_over_2x_median_wall_fraction':max(r['over_2x_median_wall_fraction'] for r in g),
                'maximum_over_2x_median_count':max(r['over_2x_median_count'] for r in g)})
out={'scope':'all1600 prior calibration processes; descriptive diagnosis only',
     'source_script_sha256':sha(Path(__file__)),'inputs':inputs,'processes':items,'groups':groups,
     'previous_qualification_changed':False,'new_gate_or_tail_exclusion':False}
(H/'previous-tail-diagnosis.json').write_text(json.dumps(out,indent=2)+'\n')
for r in groups:
    print(r['arch'],r['K'],r['case'],'log SD rate/median',round(r['paired_log_throughput_sd'],4),
          round(r['paired_log_median_latency_sd'],4),'mean/median',round(r['median_mean_over_median'],3),
          'top1%',round(r['median_top_1pct_wall_fraction']*100,2),'max_ms',round(r['maximum_operation_ns']/1e6,3))
