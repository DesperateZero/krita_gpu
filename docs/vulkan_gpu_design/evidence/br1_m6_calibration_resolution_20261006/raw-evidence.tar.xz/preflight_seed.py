"""Bounded seed-harness smoke: both images, layouts and selection arms."""
from pathlib import Path
import json,os,subprocess,time

H=Path(__file__).resolve().parent;R=H.parents[3]/'krita';B=R/'_build-br0-cpu'
P=H.parent/'br1_m6_provider_borrow_20261006';O=H/'seed-preflight';O.mkdir();runs=[]
base=dict(os.environ,QT_QPA_PLATFORM='offscreen',KIS_BR1_PROFILE='0',KIS_BR1_STAGE_PROFILE='0',
 KIS_TEST_PREFIX_PATH=str(R/'_install'),KIS_TEST_PLUGIN_PATH=str(B/'bin'),M6_DIAGNOSTIC_QOS='unchanged')
base.pop('QT_HASH_SEED',None);base.pop('M6_MECHANISM',None)
for arch in ['arm64','x86_64']:
 for case in ['hit','native-pin']:
  for deterministic in [False,True]:
   for image,mode in [('original','fixed'),('selection','fixed'),('selection','paired')]:
    libdir=B/'bin' if image=='original' else P/'selection-image'
    env=dict(base)
    if deterministic:env['QT_HASH_SEED']='0'
    cmd=['arch','-'+arch,'/usr/bin/env','DYLD_LIBRARY_PATH='+str(libdir)+':'+str(B/'bin'),
     'DYLD_PRINT_LIBRARIES=1',str(H/f'probe-seed-{arch}/probe'),mode,case,'16','0','1000000','1','0','2']
    log=O/f'{len(runs):03d}-{arch}-{case}-{deterministic}-{image}-{mode}.log';start=time.monotonic()
    with log.open('x') as f:
     child=subprocess.Popen(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
     try:code=child.wait(timeout=120);timeout=False
     except subprocess.TimeoutExpired:child.kill();code=child.wait(timeout=5);timeout=True
    raw=log.read_text();layout=json.loads(next(s[7:] for s in raw.splitlines() if s.startswith('LAYOUT ')))
    rows=[json.loads(s[7:]) for s in raw.splitlines() if s.startswith('WINDOW ')]
    record={'arch':arch,'case':case,'deterministic':deterministic,'image':image,'mode':mode,
     'command':cmd,'environment':{'QT_HASH_SEED':'0' if deterministic else None},'exit_code':code,
     'timed_out':timeout,'reaped':True,'seconds':time.monotonic()-start,'log':log.name,'layout':layout}
    runs.append(record);log.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n')
    assert not code and not timeout and str(libdir/'libkritaimage.21.0.0.dylib') in raw
    assert 'all_checks_passed=1' in raw and len(rows)==1 and len(rows[0]['arms'])==(2 if mode=='paired' else 1)
    assert layout['deterministic_requested']==deterministic and (layout['hash_seed']==0)==deterministic
    for a in rows[0]['arms']:
     n=a['completed'];assert len(a['operation_ns'])==n and sum(a['operation_ns'])==a['wall_ns']
     hit=case=='hit' and not a['disabled']
     assert a['handoffs']==(16*n if hit else 0) and a['copy_bytes']==(0 if hit else 16*n*16384)
assert len(runs)==24
(O/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
print('24 seed preflight processes passed; layout, work and full close checked')
