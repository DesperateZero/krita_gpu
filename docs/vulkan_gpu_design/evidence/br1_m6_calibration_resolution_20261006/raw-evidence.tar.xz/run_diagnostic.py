"""Prospectively fixed A/A, image and main-thread scheduling controls."""
from pathlib import Path
import hashlib,json,math,os,re,resource,statistics,subprocess,time

H=Path(__file__).resolve().parent;R=H.parents[3]/'krita';B=R/'_build-br0-cpu'
P=H.parent/'br1_m6_provider_borrow_20261006'
plan=json.loads((H/'diagnostic-protocol.json').read_text())
identity=json.loads((H/'start-identity.json').read_text())['inputs']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
freeze=json.loads((H/'diagnostic-freeze.json').read_text())
for p,w in identity.items():assert sha(p)==w,p
for p,w in freeze['files'].items():assert sha(p)==w,p
O=H/'diagnostic';O.mkdir();(O/'identity-before.json').write_text(json.dumps(identity,indent=2)+'\n')
resource.setrlimit(resource.RLIMIT_CORE,(0,0));runs=[]
baseenv=dict(os.environ,QT_QPA_PLATFORM='offscreen',KIS_BR1_PROFILE='0',KIS_BR1_STAGE_PROFILE='0',
 KIS_TEST_PREFIX_PATH=str(R/'_install'),KIS_TEST_PLUGIN_PATH=str(B/'bin'))
baseenv.pop('M6_MECHANISM',None)
buckets=[(a,k,c,cell) for a in plan['architectures'] for k in plan['K'] for c in plan['cases'] for cell in plan['cells']]
for pair in range(plan['pairs']):
    offset=pair%len(buckets)
    for arch,k,case,cell in buckets[offset:]+buckets[:offset]:
        for arm in ([0,1] if pair%2==0 else [1,0]):
            libdir=P/'selection-image' if arm and cell.startswith('cross-image') else B/'bin'
            qos='user-initiated' if cell.endswith('user-initiated') else 'unchanged'
            env=dict(baseenv,M6_DIAGNOSTIC_QOS=qos);w=plan['window']
            cmd=['arch','-'+arch,'/usr/bin/env','DYLD_LIBRARY_PATH='+str(libdir)+':'+str(B/'bin'),
                 'DYLD_PRINT_LIBRARIES=1',str(H/f'probe-01-{arch}/probe'),'fixed',case,str(k),'0',
                 str(w['minimum_operation_ns']),str(w['warmup']),str(pair%2),str(w['minimum_operations'])]
            log=O/f'{len(runs):04d}-{arch}-k{k}-{case}-{cell}-{arm}.log';start=time.monotonic()
            with log.open('x') as f:
                child=subprocess.Popen(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
                try:code=child.wait(timeout=120);timeout=False
                except subprocess.TimeoutExpired:child.kill();code=child.wait(timeout=5);timeout=True
            raw=log.read_text();row={'pair':pair,'arch':arch,'K':k,'case':case,'cell':cell,'arm':arm,
             'command':cmd,'environment_overrides':{'M6_DIAGNOSTIC_QOS':qos},'log':log.name,'pid':child.pid,
             'exit_code':code,'timed_out':timeout,'reaped':True,'seconds':time.monotonic()-start,
             'image_loaded':str(libdir/'libkritaimage.21.0.0.dylib') in raw,
             'failures':re.findall(r'^.*(?:FAIL!|FATAL|SAFE ASSERT|ASSERT failure|sample_failed).*$' ,raw,re.M)}
            runs.append(row);log.with_suffix('.json').write_text(json.dumps(row,indent=2)+'\n')
            assert not code and not timeout and row['image_loaded'] and not row['failures'],row
            records=[json.loads(t.removeprefix('WINDOW ')) for t in raw.splitlines() if t.startswith('WINDOW ')]
            assert len(records)==1 and 'all_checks_passed=1' in raw
            data=records[0];assert not data['paired'] and data['switch_loaded']==(arm==1 and cell.startswith('cross-image'))
            assert len(data['arms'])==1 and data['case']==case and data['K']==k
            a=data['arms'][0];ns=a.pop('operation_ns');n=len(ns);med=statistics.median(ns)
            assert n==a['completed'] and sum(ns)==a['wall_ns'] and all(t>0 for t in ns)
            assert a['wall_ns']>=w['minimum_operation_ns'] and n>=w['minimum_operations']
            assert a['handoffs']==(k*n if case=='hit' else 0) and a['copy_bytes']==(0 if case=='hit' else k*n*16384)
            a.update(median_ns=med,mean_ns=sum(ns)/n,throughput=n*1e9/sum(ns),maximum_ns=max(ns),
             top_1pct_wall_fraction=sum(sorted(ns)[-max(1,math.ceil(n*.01)):])/sum(ns),
             operation_vector_sha256=hashlib.sha256(json.dumps(ns).encode()).hexdigest())
            row.update(observation=a,qos=json.loads(next(t.removeprefix('ENV ') for t in raw.splitlines() if t.startswith('ENV '))),
                       context=json.loads(next(t.removeprefix('CONTEXT ') for t in raw.splitlines() if t.startswith('CONTEXT '))))
            assert qos!='user-initiated' or row['qos']['qos_after']==25
            log.with_suffix('.json').write_text(json.dumps(row,indent=2)+'\n')
    print(json.dumps({'pair':pair+1,'processes':len(runs)}),flush=True)
assert len(runs)==768
(O/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
for p,w in identity.items():assert sha(p)==w,p
for p,w in freeze['files'].items():assert sha(p)==w,p
(O/'identity-final.json').write_text(json.dumps({'inputs':identity,'frozen_files':freeze['files'],'verified':True},indent=2)+'\n')
print('D2 complete768, all checks and identities passed',flush=True)
