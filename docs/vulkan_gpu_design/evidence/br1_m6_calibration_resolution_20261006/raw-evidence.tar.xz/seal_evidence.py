"""Seal all raw attempts, harness builds and reused image bytes after verification."""
from pathlib import Path
import hashlib,json,shutil,tarfile

H=Path(__file__).resolve().parent;R=H.parents[3]/'krita';P=H.parent/'br1_m6_provider_borrow_20261006'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
verification=json.loads((H/'verification.json').read_text())
assert verification['new_diagnostic_processes']==1920 and verification['production_files_changed']==0
images=[]
for name,source in [('original-current',R/'_build-br0-cpu/bin/libkritaimage.21.0.0.dylib'),
                    ('normal-on-selection',P/'selection-image/libkritaimage.21.0.0.dylib')]:
 destination=H/'preserved-images'/name/source.name
 destination.parent.mkdir(parents=True,exist_ok=False);shutil.copyfile(source,destination)
 assert sha(destination)==sha(source)
 images.append({'actual_loaded_path':str(source),'preserved_copy':str(destination.relative_to(H)),
                'sha256':sha(source),'meaning':'Same bytes as experiment-loaded image; dependency hashes in start-identity.json'})
(H/'preserved-images/identity.json').write_text(json.dumps(images,indent=2)+'\n')
excluded={'raw-evidence.tar.xz','artifact-manifest.json','delivery.json','docs-verification.json','stage-files.json'}
files=sorted(p for p in H.rglob('*') if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts)
manifest={str(p.relative_to(H)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in files}
archive=H/'raw-evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=3) as tar:
 for path in files:tar.add(path,arcname=str(path.relative_to(H)),recursive=False)
with tarfile.open(archive,'r:xz') as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for member in members:
  assert member.isfile() and hashlib.sha256(tar.extractfile(member).read()).hexdigest()==manifest[member.name]['sha256']
report={'archive':archive.name,'members':len(files),'expanded_bytes':sum(r['bytes'] for r in manifest.values()),
        'compressed_bytes':archive.stat().st_size,'sha256':sha(archive),'members_verified':True,'files':manifest,
        'reused_library_images':images,'dependency_identity':'2504 inputs in start-identity.json; source product38834c4e26'}
(H/'artifact-manifest.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['files','reused_library_images']},indent=2))
