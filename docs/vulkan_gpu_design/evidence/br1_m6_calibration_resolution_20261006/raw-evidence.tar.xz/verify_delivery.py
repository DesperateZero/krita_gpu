"""Verify the finite diagnostics and unchanged product, without resampling."""
from pathlib import Path
import hashlib,json,math,statistics,subprocess

H=Path(__file__).resolve().parent;R=H.parents[3]/'krita'
load=lambda n:json.loads((H/n).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
start=load('start-identity.json')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head==start['product']
assert subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=R,text=True)==''
for path,want in start['inputs'].items():assert sha(path)==want,path
previous=load('previous-tail-diagnosis.json')
assert len(previous['processes'])==1600
for path,want in previous['inputs'].items():assert sha(path)==want,path
original=(H.parent/'br1_m6_provider_borrow_20261006/baseline.cpp').read_text()
sample_body=lambda s:s[s.index('static bool sample('):s.index('\nint main(')]
assert all(sample_body((H/n).read_text())==sample_body(original)
 for n in ['baseline.cpp','baseline-seed.cpp'])
unchanged_sample_body_sha256=hashlib.sha256(sample_body(original).encode()).hexdigest()

scopes={}
for scope,prefix,count in [('diagnostic','diagnostic',768),('seed-diagnostic','seed',384),('window-diagnostic','window',768)]:
 freeze=load(prefix+'-freeze.json')
 for path,want in freeze['files'].items():assert sha(path)==want,path
 assert load(scope+'/identity-final.json')['verified']
 rows=load(scope+'/runs.json');assert len(rows)==count
 operations=0;wall=0;worst=0;tails=[]
 for row in rows:
  assert row['exit_code']==0 and not row['timed_out'] and row['reaped'] and row['image_loaded'] and not row['failures']
  raw=(H/scope/row['log']).read_text()
  assert 'all_checks_passed=1' in raw
  records=[json.loads(t[7:]) for t in raw.splitlines() if t.startswith('WINDOW ')]
  assert len(records)==1 and not records[0]['paired'] and len(records[0]['arms'])==1
  record=records[0];a=record['arms'][0];ns=a['operation_ns'];n=len(ns)
  assert n==a['completed'] and n>=128 and all(t>0 for t in ns)
  assert sum(ns)==a['wall_ns'] and a['wall_ns']>=record['minimum_ns']
  assert hashlib.sha256(json.dumps(ns).encode()).hexdigest()==row['observation']['operation_vector_sha256']
  assert a['handoffs']==(row['K']*n if row['case']=='hit' else 0)
  assert a['copy_bytes']==(0 if row['case']=='hit' else row['K']*n*16384)
  closed=a['last_closed_budget'];assert len(closed)==7
  assert all(b[1]==0 and (i==6 or b[0]==0) for i,b in enumerate(closed))
  operations+=n;wall+=a['wall_ns'];worst=max(worst,max(ns))
  tails.append(sum(sorted(ns)[-max(1,math.ceil(n*.01)):])/sum(ns))
 scopes[scope]={'processes':count,'completed_operations':operations,'operation_wall_ns':wall,
  'maximum_operation_ns':worst,'median_top1pct_wall_fraction':statistics.median(tails),
  'all_work_exit_vectors_and_frozen_inputs_verified':True,'frozen_files':len(freeze['files'])}

for scope,count in [('preflight',48),('seed-preflight',24)]:
 rows=load(scope+'/runs.json');assert len(rows)==count
 assert all(r['exit_code']==0 and r['reaped'] and not r['timed_out'] for r in rows)
 scopes[scope]={'processes':count,'all_processes_passed':True}
report={'product_head':head,'production_files_changed':0,'production_api_owner_fields_added':0,
 'candidate_inputs_verified':len(start['inputs']),'retrospective_processes':1600,
 'unchanged_complete_sample_body_sha256':unchanged_sample_body_sha256,
 'retrospective_inputs_verified':len(previous['inputs']),'scopes':scopes,
 'new_diagnostic_processes':1920,'new_preflight_processes':72,
 'new_completed_operation_samples':sum(d.get('completed_operations',0) for d in scopes.values()),
 'no_optional_extension_tail_removal_or_previous_requalification':True,
 'current_safety_resources_structure':'Inherited unchanged product evidence11180/0/0,6 resource probes and architecture/tool checks; no new full safety run',
 'closed_budget_scope':'Snapshot taken after close while Store is alive; MetadataArena live retained until Store destruction. Destruction/drain occurs before sample return; no invented post-destruction snapshot.',
 'formal_calibration_equivalent':2,'formal_calibration_required':20,
 'M6_complete':False,'persistent_default_enabled':False,
 'verification_script_sha256':sha(Path(__file__))}
(H/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
