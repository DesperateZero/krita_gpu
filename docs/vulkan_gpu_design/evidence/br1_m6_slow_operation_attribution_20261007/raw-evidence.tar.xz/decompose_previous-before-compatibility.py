"""Exact throughput decomposition; diagnostic factors never replace gate samples."""
from pathlib import Path
import collections,hashlib,json,math,statistics
H=Path(__file__).resolve().parent;P=H.parent/'br1_m6_calibration_resolution_20261006'
rows=json.loads((P/'window-diagnostic/runs.json').read_text());groups=collections.defaultdict(list)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={str(P/'window-diagnostic/runs.json'):sha(P/'window-diagnostic/runs.json')}
for row in rows:
 p=P/'window-diagnostic'/row['log'];inputs[str(p)]=sha(p)
 data=json.loads(next(t[7:] for t in p.read_text().splitlines() if t.startswith('WINDOW ')))['arms'][0]
 ns=data['operation_ns'];assert len(ns)==data['completed'] and sum(ns)==data['wall_ns']
 m=statistics.median(ns);mean=sum(ns)/len(ns)
 groups[(row['arch'],row['K'],row['case'],row['cell'])].append(dict(pair=row['pair'],arm=row['arm'],
  median=m,shape=mean/m,mean=mean,n=len(ns),wall=sum(ns),
  slow_n=sum(t>=1000000 for t in ns),slow_wall=sum(t for t in ns if t>=1000000)))
out=[]
for key,g in groups.items():
 rate=[];bulk=[];shape=[]
 for pair in range(12):
  a,b=[next(r for r in g if r['pair']==pair and r['arm']==arm) for arm in [0,1]]
  rate.append(math.log(a['mean']/b['mean']))
  bulk.append(math.log(a['median']/b['median']))
  shape.append(math.log(a['shape']/b['shape']))
 assert max(abs(x-y-z) for x,y,z in zip(rate,bulk,shape))<1e-12
 balanced=lambda v:[(v[i]+v[i+1])/2 for i in range(0,12,2)]
 rr,bb,ss=map(balanced,[rate,bulk,shape]);v=statistics.variance(rr)
 cov=statistics.covariance(bb,ss)
 out.append(dict(arch=key[0],K=key[1],case=key[2],cell=key[3],completed=sum(r['n'] for r in g),
  slow_n=sum(r['slow_n'] for r in g),slow_wall_fraction=sum(r['slow_wall'] for r in g)/sum(r['wall'] for r in g),
  process_median_range=[min(r['median'] for r in g),max(r['median'] for r in g)],
  paired_log_sd={'rate':statistics.stdev(rate),'bulk_median':statistics.stdev(bulk),'shape':statistics.stdev(shape)},
  balanced_block_variance={'rate':v,'bulk_median':statistics.variance(bb),'shape':statistics.variance(ss),'twice_covariance':2*cov},
  exact_log_factors={'rate':rr,'bulk_median':bb,'shape':ss}))
(H/'previous-decomposition.json').write_text(json.dumps({'inputs':inputs,'rows':out,
 'identity':'log(rate_R/rate_L)=log(median_L/median_R)+log((mean_L/median_L)/(mean_R/median_R)); exact; no tail deletion or normalization',
 'scope':'Frozen D4 only; variation factors descriptive, not causal CPU/OS shares and not new qualification'},indent=2)+'\n')
for r in out:
 if r['cell'].endswith('512ms'):print(json.dumps({k:v for k,v in r.items() if k!='exact_log_factors'}))
