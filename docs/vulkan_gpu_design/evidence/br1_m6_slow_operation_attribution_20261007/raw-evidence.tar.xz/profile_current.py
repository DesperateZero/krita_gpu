from pathlib import Path
import hashlib,json,os,re,subprocess,time
H=Path(__file__).resolve().parent;R=H.parents[3]/'krita';B=R/'_build-br0-cpu'
D=H.parent/'br1_m6_calibration_resolution_20261006';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
freeze=json.loads((H/'profile-freeze.json').read_text())
for p,w in freeze['files'].items():assert sha(p)==w,p
runs=[]
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',KIS_BR1_PROFILE='0',KIS_BR1_STAGE_PROFILE='0',
 KIS_TEST_PREFIX_PATH=str(R/'_install'),KIS_TEST_PLUGIN_PATH=str(B/'bin'),M6_DIAGNOSTIC_QOS='unchanged')
env.pop('QT_HASH_SEED',None);env.pop('M6_MECHANISM',None)
for k,case in [(1,'native-pin'),(16,'hit')]:
 out=H/f'profile-k{k}-{case}';out.mkdir()
 cmd=['arch','-arm64','/usr/bin/env','DYLD_LIBRARY_PATH='+str(B/'bin'),'DYLD_PRINT_LIBRARIES=1',
  str(D/'probe-seed-arm64/probe'),'fixed',case,str(k),'0','5000000000','8','0','128']
 start=time.monotonic()
 with (out/'fixture.log').open('x') as f:
  p=subprocess.Popen(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
  deadline=time.monotonic()+20
  while 'LAYOUT ' not in (out/'fixture.log').read_text():
   if p.poll() is not None or time.monotonic()>deadline:p.kill();p.wait(timeout=5);raise RuntimeError('LAYOUT not flushed')
   time.sleep(.02)
  pcmd=['xcrun','xctrace','record','--template','Time Profiler','--attach',str(p.pid),
   '--time-limit','3s','--output',str(out/'cpu.trace'),'--no-prompt']
  with (out/'profiler.log').open('x') as pf:
   q=subprocess.Popen(pcmd,stdout=pf,stderr=subprocess.STDOUT)
   try:qc=q.wait(timeout=45);qt=False
   except subprocess.TimeoutExpired:q.kill();qc=q.wait(timeout=5);qt=True
  try:code=p.wait(timeout=max(1,120-(time.monotonic()-start)));timeout=False
  except subprocess.TimeoutExpired:p.kill();code=p.wait(timeout=5);timeout=True
 raw=(out/'fixture.log').read_text()
 row=dict(K=k,case=case,command=cmd,profiler_command=pcmd,exit_code=code,profiler_exit_code=qc,
  timed_out=timeout,profiler_timed_out=qt,reaped=True,profiler_reaped=True,seconds=time.monotonic()-start,
  loaded_original=str(B/'bin/libkritaimage.21.0.0.dylib') in raw,
  failures=re.findall(r'^.*(?:FAIL!|FATAL|SAFE ASSERT|ASSERT failure|sample_failed).*$',raw,re.M))
 (out/'result.json').write_text(json.dumps(row,indent=2)+'\n');runs.append(row)
 assert code==0 and qc==0 and not timeout and not qt and row['loaded_original'] and not row['failures'] and 'all_checks_passed=1' in raw,row
 export=['xcrun','xctrace','export','--input',str(out/'cpu.trace'),'--xpath',
  '/trace-toc/run[@number="1"]/data/table[@schema="time-profile"]','--output',str(out/'time-profile.xml')]
 (out/'export-command.json').write_text(json.dumps(export,indent=2)+'\n')
 with (out/'export.log').open('x') as ef:subprocess.run(export,stdout=ef,stderr=subprocess.STDOUT,check=True,timeout=60)
 print(json.dumps({'K':k,'case':case,'fixture_profiler_export_ok':True}),flush=True)
for p,w in freeze['files'].items():assert sha(p)==w,p
(H/'profile-runs.json').write_text(json.dumps(runs,indent=2)+'\n')
