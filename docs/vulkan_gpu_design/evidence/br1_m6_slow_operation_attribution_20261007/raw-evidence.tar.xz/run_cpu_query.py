from pathlib import Path
import hashlib,json,os,re,resource,subprocess,time
H=Path(__file__).resolve().parent;R=H.parents[3]/'krita';B=R/'_build-br0-cpu'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
freeze=json.loads((H/'cpu-query-freeze.json').read_text())
for p,w in freeze['files'].items():assert sha(p)==w,p
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',KIS_BR1_PROFILE='0',KIS_BR1_STAGE_PROFILE='0',
 KIS_TEST_PREFIX_PATH=str(R/'_install'),KIS_TEST_PLUGIN_PATH=str(B/'bin'),M6_DIAGNOSTIC_QOS='unchanged')
env.pop('QT_HASH_SEED',None);env.pop('M6_MECHANISM',None)
out=H/'cpu-query-diagnostic';out.mkdir();runs=[];clocks={}
def run(arch,args,label,meta):
 cmd=['arch','-'+arch,'/usr/bin/env','DYLD_LIBRARY_PATH='+str(B/'bin'),'DYLD_PRINT_LIBRARIES=1',
      str(H/f'cpu-query-{arch}/probe'),*args]
 log=out/(label+'.log');start=time.monotonic()
 with log.open('x') as f:
  p=subprocess.Popen(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
  try:code=p.wait(timeout=120);timeout=False
  except subprocess.TimeoutExpired:p.kill();code=p.wait(timeout=5);timeout=True
 raw=log.read_text();row=dict(meta,arch=arch,command=cmd,pid=p.pid,exit_code=code,timed_out=timeout,
  reaped=True,seconds=time.monotonic()-start,log=log.name,
  loaded_original=str(B/'bin/libkritaimage.21.0.0.dylib') in raw,
  failures=re.findall(r'^.*(?:FAIL!|FATAL|SAFE ASSERT|ASSERT failure|sample_failed).*$',raw,re.M))
 log.with_suffix('.json').write_text(json.dumps(row,indent=2)+'\n');runs.append(row)
 assert code==0 and not timeout and row['loaded_original'] and not row['failures'] and 'all_checks_passed=1' in raw,row
 return raw
groups=[(a,k,c) for a in ['arm64','x86_64'] for k in [1,16] for c in ['hit','native-pin']]
for repeat in range(4):
 offset=repeat//2;order=groups[offset:]+groups[:offset]
 if repeat%2:order=list(reversed(order))
 for arch,k,case in order:
  run(arch,['fixed',case,str(k),'0','512000000','8',str(repeat%2),'512'],
   f'{len(runs):02d}-{arch}-k{k}-{case}-r{repeat}',{'kind':'operation','K':k,'case':case,'repeat':repeat})
 print(json.dumps({'repeat':repeat+1,'processes':len(runs)}),flush=True)
for p,w in freeze['files'].items():assert sha(p)==w,p
(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
print('complete32; all exit/library/frozen identities passed',flush=True)
