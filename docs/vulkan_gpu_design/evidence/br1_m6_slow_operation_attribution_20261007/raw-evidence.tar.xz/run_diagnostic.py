from pathlib import Path
import hashlib,json,os,re,resource,subprocess,time
H=Path(__file__).resolve().parent;R=H.parents[3]/'krita';B=R/'_build-br0-cpu'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
freeze=json.loads((H/'diagnostic-freeze.json').read_text())
for p,w in freeze['files'].items():assert sha(p)==w,p
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',KIS_BR1_PROFILE='0',KIS_BR1_STAGE_PROFILE='0',
 KIS_TEST_PREFIX_PATH=str(R/'_install'),KIS_TEST_PLUGIN_PATH=str(B/'bin'),M6_DIAGNOSTIC_QOS='unchanged')
env.pop('QT_HASH_SEED',None);env.pop('M6_MECHANISM',None)
out=H/'diagnostic';out.mkdir();runs=[];clocks={}
def run(arch,args,label,meta):
 cmd=['arch','-'+arch,'/usr/bin/env','DYLD_LIBRARY_PATH='+str(B/'bin'),'DYLD_PRINT_LIBRARIES=1',
      str(H/f'probe-{arch}/probe'),*args]
 log=out/(label+'.log');start=time.monotonic()
 with log.open('x') as f:
  p=subprocess.Popen(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
  try:code=p.wait(timeout=120);timeout=False
  except subprocess.TimeoutExpired:p.kill();code=p.wait(timeout=5);timeout=True
 raw=log.read_text();row=dict(meta,arch=arch,command=cmd,pid=p.pid,exit_code=code,timed_out=timeout,
  reaped=True,seconds=time.monotonic()-start,log=log.name,
  loaded_original=str(B/'bin/libkritaimage.21.0.0.dylib') in raw,
  failures=re.findall(r'^.*(?:FAIL!|FATAL|SAFE ASSERT|ASSERT failure|sample_failed).*$',raw,re.M))
 log.with_suffix('.json').write_text(json.dumps(row,indent=2)+'\n');runs.append(row)
 assert code==0 and not timeout and row['loaded_original'] and not row['failures'] and 'all_checks_passed=1' in raw,row
 return raw
for arch in ['arm64','x86_64']:
 raw=run(arch,['clocks'],'clocks-'+arch,{'kind':'clocks'})
 rows=[json.loads(t[6:]) for t in raw.splitlines() if t.startswith('CLOCK ')]
 assert len(rows)==9
 clocks[arch]={}
 for name in ['thread','process']:
  key=name+'_cpu_ns'
  busy=[r[key]/r['wall_ns'] for r in rows if r['kind']=='busy']
  sleep=[r[key]/r['wall_ns'] for r in rows if r['kind']=='sleep']
  clocks[arch][name]={'busy_ratios':busy,'sleep_ratios':sleep,
   'valid':all(.9<=v<=1.1 for v in busy) and all(v<.1 for v in sleep),
   'empty_ns':[r[key] for r in rows if r['kind']=='empty']}
 assert clocks[arch]['process']['valid'],clocks[arch]
(out/'clock-validation.json').write_text(json.dumps(clocks,indent=2)+'\n')
groups=[(a,k,c) for a in ['arm64','x86_64'] for k in [1,16] for c in ['hit','native-pin']]
for repeat in range(4):
 offset=repeat//2;order=groups[offset:]+groups[:offset]
 if repeat%2:order=list(reversed(order))
 for arch,k,case in order:
  run(arch,['fixed',case,str(k),'0','128000000','8',str(repeat%2),'512'],
   f'{len(runs):02d}-{arch}-k{k}-{case}-r{repeat}',{'kind':'operation','K':k,'case':case,'repeat':repeat})
 print(json.dumps({'repeat':repeat+1,'processes':len(runs)}),flush=True)
for p,w in freeze['files'].items():assert sha(p)==w,p
(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
print('complete34; all exit/library/frozen identities passed',flush=True)
