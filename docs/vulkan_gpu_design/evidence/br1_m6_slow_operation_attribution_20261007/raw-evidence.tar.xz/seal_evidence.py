from pathlib import Path
import hashlib,json,shutil,tarfile
H=Path(__file__).resolve().parent;R=H.parents[3]/'krita';P=H.parent/'br1_m6_provider_borrow_20261006'
D=H.parent/'br1_m6_calibration_resolution_20261006';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((H/'verification.json').read_text())['all_evidence_integrity_and_measurement_checks_passed']
images=[]
for name,source in [('original-current',R/'_build-br0-cpu/bin/libkritaimage.21.0.0.dylib'),
 ('normal-on-selection',P/'selection-image/libkritaimage.21.0.0.dylib'),
 *[(f'uninstrumented-probe-{a}',D/f'probe-seed-{a}/probe') for a in ['arm64','x86_64']]]:
 target=H/'preserved-images'/name/source.name;target.parent.mkdir(parents=True,exist_ok=False)
 shutil.copyfile(source,target);assert sha(source)==sha(target)
 images.append(dict(actual_loaded_path=str(source),preserved_copy=str(target.relative_to(H)),sha256=sha(source)))
(H/'preserved-images/identity.json').write_text(json.dumps(images,indent=2)+'\n')
excluded={'raw-evidence.tar.xz','artifact-manifest.json','delivery.json','docs-verification.json','stage-files.json','seal.log'}
files=sorted(p for p in H.rglob('*') if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts)
manifest={str(p.relative_to(H)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in files}
archive=H/'raw-evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=3) as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(H)),recursive=False)
with tarfile.open(archive,'r:xz') as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for member in members:
  assert member.isfile() and hashlib.sha256(tar.extractfile(member).read()).hexdigest()==manifest[member.name]['sha256']
result=dict(archive=archive.name,members=len(files),expanded_bytes=sum(v['bytes'] for v in manifest.values()),
 compressed_bytes=archive.stat().st_size,sha256=sha(archive),members_verified=True,files=manifest,preserved_images=images)
(H/'artifact-manifest.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['files','preserved_images']},indent=2))
