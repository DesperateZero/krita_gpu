from pathlib import Path
import hashlib,json,re,subprocess
H=Path(__file__).resolve().parent;ROOT=H.parents[3]
docs=['docs/vulkan_gpu_design/92_br1_m6_m8_execution_baseline.md','docs/vulkan_gpu_design/README.md',
 *['docs/vulkan_gpu_design/br1_modification_guide/'+n for n in ['07_validation_and_migration.md',
 'API_CONVERGENCE_MAP.md','CODE_INDEX.md','CONVERGENCE_CHECKLIST.md','NEXT_EDITS.md','README.md','STAGE_MAP.md']]]
checks=[]
for name in docs:
 p=ROOT/name
 diff=subprocess.check_output(['git','diff','--unified=0','--',name],cwd=ROOT,text=True)
 added='\n'.join(t[1:] for t in diff.splitlines() if t.startswith('+') and not t.startswith('+++'))
 checks.append((p,added))
checks.extend((p,p.read_text()) for p in H.glob('*.md'))
links=[]
for source,content in checks:
 for target in re.findall(r'\]\(([^)]+)\)',content):
  if target.startswith(('http:','https:','app:')):continue
  target=target.strip('<>');name,_,anchor=target.partition('#')
  path=(source.parent/name).resolve() if name else source
  assert 'archive' not in path.parts,(source,target)
  assert path.exists(),(source,target)
  if anchor:
   text=path.read_text()
   explicit=bool(re.search(r'id=["\']'+re.escape(anchor)+r'["\']',text))
   headings=[]
   for heading in re.findall(r'^#+\s+(.+)$',text,re.M):
    slug=re.sub(r'[^\w\-\s]','',heading.lower()).replace(' ','-')
    headings.append(slug)
   assert explicit or anchor in headings,(source,target,anchor)
  links.append({'source':str(source.relative_to(ROOT)),'target':str(path),'anchor':anchor})
subprocess.run(['git','diff','--check','--',*docs],cwd=ROOT,check=True)
assert all('m6-execution-variance' in (ROOT/n).read_text() or 'slow_operation_attribution' in (ROOT/n).read_text() for n in docs)
result={'changed_active_documents':len(docs),'checked_links':len(links),'no_archive_links_added':True,'all_passed':True,
 'documents':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in docs},'links':links}
(H/'docs-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('active docs9; new links',len(links),'all passed')
