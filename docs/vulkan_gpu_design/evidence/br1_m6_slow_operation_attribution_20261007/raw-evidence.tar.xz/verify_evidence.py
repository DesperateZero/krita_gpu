from pathlib import Path
import hashlib,json,subprocess
H=Path(__file__).resolve().parent;R=H.parents[3]/'krita';P=H.parent/'br1_m6_calibration_resolution_20261006'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='38834c4e2612c819f9d088dfd59c59889f295a49'
assert not subprocess.check_output(['git','status','--short','--untracked-files=no'],cwd=R,text=True).strip()
frozen={}
for name in ['diagnostic','reference','cpu-query','local-block','profile']:
 f=json.loads((H/(name+'-freeze.json')).read_text())['files']
 for p,w in f.items():
  assert sha(p)==w,p
  if p in frozen:assert frozen[p]==w
  frozen[p]=w
previous=json.loads((H/'previous-decomposition.json').read_text())['inputs']
for p,w in previous.items():assert sha(p)==w,p
original=(P/'baseline-seed.cpp').read_text()
def timed(s):
 start=s.index('        const auto begin = now();')
 end=s.index('        const auto end = now(); lastEnd = end;',start)+len('        const auto end = now(); lastEnd = end;')
 return s[start:end]
body=timed(original)
for name in ['baseline.cpp','baseline-reference.cpp','baseline-cpu-query.cpp']:
 assert timed((H/name).read_text())==body,name
counts={};total=0
for dirname,expected in [('diagnostic',34),('reference-diagnostic',16),('cpu-query-diagnostic',32),('local-block',192)]:
 runs=json.loads((H/dirname/'runs.json').read_text());assert len(runs)==expected
 n=0;budgets=0;vectors=[]
 for row in runs:
  assert row['exit_code']==0 and row['reaped'] and not row['timed_out'] and not row['failures']
  raw=(H/dirname/row['log']).read_text();assert 'all_checks_passed=1' in raw
  if row.get('kind')=='clocks':continue
  d=json.loads(next(t[7:] for t in raw.splitlines() if t.startswith('WINDOW ')))
  assert not d['paired'] and len(d['arms'])==1
  a=d['arms'][0];v=a['operation_ns'];size=len(v)
  assert size==a['completed'] and sum(v)==a['wall_ns'] and min(v)>0
  assert a['handoffs']==(row['K']*size if row['case']=='hit' else 0)
  assert a['copy_bytes']==(0 if row['case']=='hit' else row['K']*size*16384)
  closed=a['last_closed_budget'];assert all(b[1]==0 for b in closed)
  assert sum(b[0]>0 for b in closed)<=1
  if dirname=='diagnostic':assert len(a['cpu_ns'])==len(a['operation_context'])==size
  if dirname=='reference-diagnostic':assert len(a['reference'])==len(a['cpu_ns'])==size
  if dirname=='cpu-query-diagnostic':assert len(a['cpu_queries'])==size
  vectors.append(dict(log=row['log'],completed=size,wall_ns=sum(v),sha256=hashlib.sha256(json.dumps(v).encode()).hexdigest()))
  n+=size;budgets+=1
 counts[dirname]={'processes':expected,'completed_operations':n,'closed_budget_snapshots':budgets,'vectors':vectors}
 total+=n
assert sum(v['processes'] for v in counts.values())==274
profile=json.loads((H/'profile-runs.json').read_text());assert len(profile)==2
failed=[];profile_operations=0
for row in profile:
 out=H/f"profile-k{row['K']}-{row['case']}";raw=(out/'fixture.log').read_text()
 assert row['reaped'] and row['profiler_reaped'] and row['profiler_exit_code']==0
 assert not row['timed_out'] and not row['profiler_timed_out'] and row['loaded_original']
 if row['K']==1:
  assert row['exit_code']==3 and 'fixed safety bound reached' in raw and 'all_checks_passed=1' not in raw
  failed.append({'K':1,'exit_code':3,'reason':'registered5s operation window exceeds fixed100000 safety cap; preserved, not rerecorded'})
 else:
  assert row['exit_code']==0 and 'all_checks_passed=1' in raw
  d=json.loads(next(t[7:] for t in raw.splitlines() if t.startswith('WINDOW ')))['arms'][0]
  assert len(d['operation_ns'])==d['completed'] and sum(d['operation_ns'])==d['wall_ns']
  assert d['handoffs']==16*d['completed'] and d['copy_bytes']==0
  profile_operations+=d['completed']
continuation=json.loads((H/'profile-continuation.json').read_text())
assert sha(H/'profile_remaining.py')==continuation['source_sha256']
result={'product':'38834c4e2612c819f9d088dfd59c59889f295a49','product_tracked_tree_clean':True,
 'frozen_inputs_verified':len(frozen),'previous_D4_inputs_verified':len(previous),
 'timed_work_body_unchanged_sha256':hashlib.sha256(body.encode()).hexdigest(),
 'new_processes':274,'completed_operations':total,'scopes':counts,
 'profile_attempts':2,'profile_fixture_passed':1,'profile_fixture_failed':failed,
 'profile_completed_operations_separate_from_measurement':profile_operations,
 'safety_inheritance':'Same verified product/runtime/test inputs;11180/0/0, six resources and structure unchanged; not rerun',
 'close_scope':'closed snapshots while Store alive, metadata may live; original sample destroys Store and drains before return',
 'all_evidence_integrity_and_measurement_checks_passed':True}
(H/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='scopes'},indent=2))
