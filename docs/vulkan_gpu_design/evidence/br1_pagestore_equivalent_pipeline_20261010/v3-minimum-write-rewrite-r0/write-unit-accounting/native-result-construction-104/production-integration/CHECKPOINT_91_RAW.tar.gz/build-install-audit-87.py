from pathlib import Path
import json,shlex,subprocess,os,hashlib
p=Path(__file__).resolve().parent;b=p/'build';out=p/'install-audit-87';out.mkdir(exist_ok=True)
s=(p/'allocation-interposer-free-stack.cpp').read_text()
s='#include <atomic>\n#include <cstdio>\nstatic std::atomic<size_t> completedAudits{0};\n'+s
s=s.replace('active = false; return counts;', 'active = false; ++completedAudits; return counts;')
s+='\n__attribute__((destructor)) static void reportAudits() { std::fprintf(stderr,"NATIVE_INSTALL_WINDOWS=%zu\\n", completedAudits.load()); }\n'
(out/'interposer.cpp').write_text(s)
cmd=['clang++','-std=c++17','-dynamiclib','-arch','arm64','-arch','x86_64',str(out/'interposer.cpp'),'-o',str(out/'interposer.dylib')]
subprocess.run(cmd,check=True)
e=next(x for x in json.loads((b/'compile_commands.json').read_text()) if x['file'].endswith('/native/KisNativeResultWrite.cpp'))
args=shlex.split(e['command']);oi=args.index('-o')+1;original=args[oi];args[oi]=str(out/'KisNativeResultWrite.cpp.o');args+=['-DNR104_INSTALL_AUDIT']
(out/'compile.json').write_text(json.dumps(args,indent=2))
with (out/'compile.log').open('w') as f:subprocess.run(args,cwd=e['directory'],stdout=f,stderr=subprocess.STDOUT,check=True)
lines=subprocess.check_output(['/Users/apple/krita_gpu/.venv/bin/ninja','-C',str(b),'-t','commands','kritaimage'],text=True).splitlines()
args=shlex.split(next(x for x in reversed(lines) if '-o bin/libkritaimage.21.0.0.dylib' in x))[2:-2]
args=[str(out/'KisNativeResultWrite.cpp.o') if x==original else x for x in args];args[args.index('-o')+1]=str(out/'libkritaimage.21.0.0.dylib');args[args.index('-install_name')+1]=str(out/'libkritaimage.21.dylib')
(out/'link.json').write_text(json.dumps(args,indent=2))
with (out/'link.log').open('w') as f:subprocess.run(args,cwd=b,stdout=f,stderr=subprocess.STDOUT,check=True)
(out/'libkritaimage.21.dylib').symlink_to('libkritaimage.21.0.0.dylib')
# Compile the existing allocator positive control into the actual native test.
e=next(x for x in json.loads((b/'compile_commands.json').read_text()) if x['file'].endswith('/NativeResultProtocolContractTest.cpp'))
args=shlex.split(e['command']);oi=args.index('-o')+1;original_test=args[oi];args[oi]=str(out/'NativeResultProtocolContractTest.cpp.o');args+=['-DNR104_INSTALL_AUDIT']
(out/'test-compile.json').write_text(json.dumps(args,indent=2))
with (out/'test-compile.log').open('w') as f:subprocess.run(args,cwd=e['directory'],stdout=f,stderr=subprocess.STDOUT,check=True)
lines=subprocess.check_output(['/Users/apple/krita_gpu/.venv/bin/ninja','-C',str(b),'-t','commands','NativeResultProtocolContractTest'],text=True).splitlines()
args=shlex.split(next(x for x in reversed(lines) if '-o bin/NativeResultProtocolContractTest.app/Contents/MacOS/NativeResultProtocolContractTest' in x))[2:-2]
args=[str(out/'NativeResultProtocolContractTest.cpp.o') if x==original_test else str(out/'libkritaimage.21.0.0.dylib') if x=='bin/libkritaimage.21.0.0.dylib' else x for x in args]
args[args.index('-o')+1]=str(out/'NativeResultProtocolContractTest')
(out/'test-link.json').write_text(json.dumps(args,indent=2))
with (out/'test-link.log').open('w') as f:subprocess.run(args,cwd=b,stdout=f,stderr=subprocess.STDOUT,check=True)
(out/'IDENTITY.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=p/'source',text=True).strip(),'diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff','HEAD'],cwd=p/'source')).hexdigest(),'audit_image_sha256':hashlib.sha256((out/'libkritaimage.21.0.0.dylib').read_bytes()).hexdigest(),'interposer_sha256':hashlib.sha256((out/'interposer.dylib').read_bytes()).hexdigest()},indent=2))
env=os.environ.copy();env.update(QT_QPA_PLATFORM='offscreen',QT_HASH_SEED='0',KIS_TEST_PREFIX_PATH='/Users/apple/krita_gpu/krita/_install',QT_PLUGIN_PATH='/Users/apple/krita_gpu/krita/_install/plugins',KIS_TEST_PLUGIN_PATH='/Users/apple/krita_gpu/krita/_build-br0-cpu/bin',DYLD_LIBRARY_PATH=str(out)+':'+str(b/'bin')+':/Users/apple/krita_gpu/krita/_build-br0-cpu/bin',DYLD_INSERT_LIBRARIES=str(out/'interposer.dylib'),DYLD_PRINT_LIBRARIES='1')
selectors=json.loads((p/'manager-complete-64.json').read_text())['command'][3:]
results=[]
for arch in ['arm64','x86_64']:
 for target,names in [('NativeResultProtocolContractTest.app/Contents/MacOS/NativeResultProtocolContractTest',[]),('kis_tiled_data_manager_test',selectors)]:
  log=out/(Path(target).name+'-'+arch+'.log');cmd=['arch','-'+arch,'/usr/bin/env',*[k+'='+v for k,v in env.items() if k.startswith(('QT_','KIS_','DYLD_'))],str(out/'NativeResultProtocolContractTest') if target.startswith('NativeResult') else str(b/'bin'/target),*names]
  rec={'command':cmd,'timeout_seconds':90,'log':log.name}
  with log.open('w') as f:
   try:r=subprocess.run(cmd,cwd=p,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90);rec['exit']=r.returncode
   except subprocess.TimeoutExpired:rec['exit']='TIMEOUT'
  import re
  raw=log.read_text();rec['windows']=[int(x) for x in re.findall(r'NATIVE_INSTALL_WINDOWS=(\d+)',raw)];rec['loaded_image']=[line for line in raw.splitlines() if 'dyld' in line and str(out/'libkritaimage') in line];rec['loaded_interposer']=[line for line in raw.splitlines() if 'dyld' in line and str(out/'interposer.dylib') in line];rec['positive_control']='NATIVE_INSTALL_POSITIVE_CONTROL_OK' in raw;rec['native_ok']='NATIVE104_CONTRACT_OK' in raw;rec['audit_ok']='NATIVE_INSTALL_AUDIT_OK' in raw
  results.append(rec);(out/'RESULTS.json').write_text(json.dumps(results,indent=2));print(arch,Path(target).name,rec['exit'],flush=True)
  if rec['exit']!=0 or not rec['windows'] or min(rec['windows'])<=0 or not rec['loaded_image'] or not rec['loaded_interposer'] or not rec['audit_ok'] or (target.startswith('NativeResult') and not (rec['positive_control'] and rec['native_ok'])):raise SystemExit(1)
