import json,shlex,subprocess,hashlib,concurrent.futures
from pathlib import Path
p=Path(__file__).resolve().parent;b=p/'build';out=p/'tsan-development';out.mkdir(exist_ok=True)
entries=json.loads((b/'compile_commands.json').read_text());selected=[];replacements={}
for entry in entries:
 file=entry['file']
 if ('/libs/image/pagestore/' in file or '/libs/image/tiles3/' in file and '/tests/' not in file or file.endswith('/NativeResultProtocolContractTest.cpp') or file.endswith('/kis_tiled_data_manager_test.cpp')):
  args=shlex.split(entry['command']);i=args.index('-o');old=args[i+1];new=out/(hashlib.sha256(old.encode()).hexdigest()[:12]+'.o');args[i+1]=str(new)
  args=[a for a in args if a!='-DNR104_INSTALL_AUDIT'];args+=['-fsanitize=thread','-include',str(p/'tsan-qt-rwlock-annotations.h')];replacements[old]=str(new);selected.append((entry,args,new))
header_identity=hashlib.sha256(b''.join(f.read_bytes() for base in ['pagestore','tiles3'] for f in sorted((p/'source/libs/image'/base).rglob('*.h')))).hexdigest()
def compile(task):
 entry,args,new=task
 identity=hashlib.sha256((json.dumps(args)+Path(entry['file']).read_text()+header_identity).encode()).hexdigest()
 stamp=new.with_suffix('.identity')
 if not (new.exists() and stamp.exists() and stamp.read_text()==identity):
  with new.with_suffix('.log').open('w') as f:r=subprocess.run(args,cwd=entry['directory'],stdout=f,stderr=subprocess.STDOUT)
  if r.returncode: return (entry['file'],r.returncode)
  stamp.write_text(identity)
 return (entry['file'],0)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 results=list(pool.map(compile,selected))
(out/'compilation.json').write_text(json.dumps({'commands':[a for _,a,_ in selected],'results':results},indent=2))
failed=[r for r in results if r[1]]
if failed:print(failed);raise SystemExit(1)
for target,search,dest in [('kritaimage','-o bin/libkritaimage.21.0.0.dylib','libkritaimage.21.0.0.dylib'),('NativeResultProtocolContractTest','-o bin/NativeResultProtocolContractTest.app/Contents/MacOS/NativeResultProtocolContractTest','NativeResultProtocolContractTest'),('kis_tiled_data_manager_test','-o bin/kis_tiled_data_manager_test','kis_tiled_data_manager_test')]:
 lines=subprocess.check_output(['/Users/apple/krita_gpu/.venv/bin/ninja','-C',str(b),'-t','commands',target],text=True).splitlines()
 cmd=[s for s in lines if search in s][-1];args=shlex.split(cmd)[2:-2]
 args=[replacements.get(a,a) for a in args];args[args.index('-o')+1]=str(out/dest);args+=['-fsanitize=thread']
 if target=='kritaimage':
  if '-install_name' in args:args[args.index('-install_name')+1]=str(out/'libkritaimage.21.dylib')
 else:
  args=[str(out/'libkritaimage.21.0.0.dylib') if a=='bin/libkritaimage.21.0.0.dylib' else a for a in args]
 with (out/(target+'-link.log')).open('w') as f:r=subprocess.run(args,cwd=b,stdout=f,stderr=subprocess.STDOUT)
 (out/(target+'-link.json')).write_text(json.dumps(args,indent=2))
 if r.returncode:print(target,'link failed');raise SystemExit(r.returncode)
 if target=='kritaimage':
  symlink=out/'libkritaimage.21.dylib'
  if not symlink.exists():symlink.symlink_to(dest)
(out/'IDENTITY-04.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=p/'source',text=True).strip(),'diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff','HEAD'],cwd=p/'source')).hexdigest(),'header_sha256':header_identity,'image_sha256':hashlib.sha256((out/'libkritaimage.21.0.0.dylib').read_bytes()).hexdigest()},indent=2))
print('instrumented native, shared PageStore services and Tiles3 objects:',len(selected),flush=True)
cmd=['arch','-arm64','/usr/bin/env','QT_QPA_PLATFORM=offscreen','QT_HASH_SEED=0','KIS_TEST_PREFIX_PATH=/Users/apple/krita_gpu/krita/_install','TSAN_OPTIONS=halt_on_error=1:exitcode=66','DYLD_PRINT_LIBRARIES=1','DYLD_LIBRARY_PATH='+str(out)+':'+str(b/'bin')+':/Users/apple/krita_gpu/krita/_build-br0-cpu/bin',str(out/'NativeResultProtocolContractTest')]
(out/'run-command.json').write_text(json.dumps(cmd,indent=2))
with (out/'run-integration-04.log').open('w') as f:
 try:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=240);result={'exit':r.returncode}
 except subprocess.TimeoutExpired:result={'timeout':True}
(out/'run-integration-04.result.json').write_text(json.dumps(result));print(result)

cmd[-1]=str(out/'kis_tiled_data_manager_test')
cmd+=['testPageStoreWholeTileFillUsesSynchronousAdoption','testPageStoreCopyLiveWriteCompatibility','testPageStoreCompatibilityCopySegmentFailure']
(out/'run-manager-04.command.json').write_text(json.dumps(cmd,indent=2))
with (out/'run-manager-04.log').open('w') as f:
 try:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=90);result={'exit':r.returncode}
 except subprocess.TimeoutExpired:result={'timeout':True}
(out/'run-manager-04.result.json').write_text(json.dumps(result));print(result)
