from pathlib import Path
root=Path(__file__).parent/'source'
def edit(file,func):
 p=root/file;s=p.read_text();s=func(s);p.write_text(s)
def cut(s,a,b):
 x=s.index(a);y=s.index(b,x);return s[:x]+s[y:]
def store(s):
 s=cut(s,'KisPageTransaction KisPageMutationSession::transaction() const','void KisPageMutationSession::returnTerminalCapacity()')
 s=cut(s,'KisMutationPageEntry *KisPageMutationSession::reserveLegacyMutationPage(', 'KisCpuWriteGuard KisPageMutationSession::beginWrite(')
 s=cut(s,'bool KisPageMutationSession::AdapterChanges::forEachImpl(', 'KisCapturedReadView KisPageMutationSession::checkpointForRead(')
 s=cut(s,'bool KisPageMutationSession::checkpointForAdapterDelivery(', 'bool KisPageMutationSession::sealImpl(')
 s=s.replace('''bool KisPageMutationSession::sealImpl(SealMode mode, QString *error, KisCapturedReadView *checkpoint,
    const AdapterPreparation &prepareAdapter, const AdapterInstallation &installAdapter)''','''bool KisPageMutationSession::sealImpl(SealMode mode, QString *error, KisCapturedReadView *checkpoint)''')
 s=s.replace('    const bool retainAdmission = mode == SealMode::AdapterDelivery || mode == SealMode::LegacyAdapterDelivery;\n','')
 s=s.replace('''((mode == SealMode::Final || mode == SealMode::AdapterDelivery)
            && d->thread != QThread::currentThreadId())''','''(mode == SealMode::Final && d->thread != QThread::currentThreadId())''')
 s=s.replace('if (!retainAdmission) d->cancelLocked();','d->cancelLocked();').replace('if (!storageRefused && !retainAdmission)', 'if (!storageRefused)')
 s=cut(s,'    // Only the bridge can transfer its private anonymous transaction', '    phase.next(Phase::MutationSealStoragePrepare,')
 s=s.replace('d->transaction, changes, &failure, &storageRefused, canonical, {}, freshlyGrouped)', 'd->transaction, changes, &failure, &storageRefused, false, {}, freshlyGrouped)')
 s=cut(s,'    const auto adapterChanges = frozenAdapterChanges();','    phase.next(Phase::MutationSealPublishOwnerWait,')
 s=s.replace('    const bool acceptsCanonical = success && hasOverlay && overlay.acceptsCanonical();\n','')
 s=s.replace('''    if (success && hasOverlay) accepted = acceptsCanonical
            ? owner->writeCoordinator.transactionHasSoleSession(d->transaction.id)
                && overlay.tryAcceptCanonicalLocked(d->diagnosticOwner, lock)
            : overlay.tryAcceptLocked(lock, &failure, &storageRefused);''','''    if (success && hasOverlay) accepted = overlay.tryAcceptLocked(lock, &failure, &storageRefused);''')
 s=s.replace('    if (acceptsCanonical) d->ownsTransaction = false;\n','')
 s=cut(s,'    if (hasOverlay && installAdapter) {','    phase.next(Phase::MutationSealCleanup, pageWork);')
 s=s.replace('d->finishSegmentLocked(lock, mode != SealMode::Checkpoint, retainAdmission);','d->finishSegmentLocked(lock, mode != SealMode::Checkpoint);')
 s=s.replace('''        if (scope->ownsTransaction) destroy(scope);
        else scope->returnTerminalCapacity();''','''        scope->returnTerminalCapacity();''')
 s=cut(s,'            if (ownsTransaction) {','            bytes = allocationBytes')
 s=cut(s,'    bool finishOwnedTransaction(bool publish)\n','    void discardCapacityUnlocked()\n')
 # The sole remaining release responsibility is cancellation of this segment;
 # the caller owns the explicit generic transaction.
 s=s.replace('cancelAndAbort(terminalWithoutFacade)', 'cancelLocked(nullptr, terminalWithoutFacade)').replace('cancelAndAbort()', 'cancelLocked()')
 s=s.replace('    bool ownsTransaction = false; // Share scalar padding; keep single-page control in its allocation class.\n','')
 s=s.replace('!retained->executions && !retained->ownsTransaction && !retained->admission.isValid()', '!retained->executions && !retained->admission.isValid()')
 a=s.index('    void finishSegmentLocked(');b=s.index('        if (terminal) owner->writeCoordinator.endSessionActivity',a)
 s=s[:a]+'''    void finishSegmentLocked(QMutexLocker<QMutex> &lock, bool terminal)
    {
        admission.releaseLocked();
        admission = {};
        // The explicit transaction remains caller-owned. End this segment's
        // actual claims before returning its reusable storage.
        ++owner->activeProviderCalls;
        lock.unlock();
        coldPages.clearValues();
        writes.clearValues();
        const size_t capacity = writes.storageBytes() + coldPages.storageBytes();
        if (capacity + allocationBytes + executionCapacity > KisBackingBudgetController::ReusableMutationBytes)
            discardCapacityUnlocked();
        lock.relock();
        --owner->activeProviderCalls;
'''+s[b:]
 return s
def header(s):
 s=cut(s,'    // Borrowed only during synchronous adapter hooks.','    KisPageMutationSession() = default;')
 s=cut(s,'    // The bridge transfers its private transaction','    KisCpuWriteGuard\n    beginWriteImpl(')
 n='    KisCpuWriteGuard\n    beginWriteImpl('
 s=s.replace(n,'''    enum class SealMode { Final, Checkpoint };
    bool sealImpl(SealMode mode, QString *error, KisCapturedReadView *checkpoint = nullptr);
    void returnTerminalCapacity();
'''+n)
 s=s.replace('    friend class KisTiledDataManagerPageStoreLease;\n','')
 return s
if 'KisPageTransaction KisPageMutationSession::transaction() const' in (root/'libs/image/pagestore/KisPageStore.cpp').read_text():
 edit('libs/image/pagestore/KisPageStore.cpp',store)
edit('libs/image/pagestore/KisPageStore.h',header)
