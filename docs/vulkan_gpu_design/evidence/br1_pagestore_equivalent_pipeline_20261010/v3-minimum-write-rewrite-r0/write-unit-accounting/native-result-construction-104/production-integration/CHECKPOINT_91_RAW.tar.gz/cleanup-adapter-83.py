from pathlib import Path
import re,json
root=Path(__file__).parent/'source';removed=[]
def remove(s,signature):
 while signature in s:
  i=s.index(signature);a=s.rfind('\n\n',0,i)+2;b=s.index('{',i);tokens=re.compile(r'//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[{}]',re.S)
  depth=0
  for t in tokens.finditer(s,b):
   if t.group()=='{':depth+=1
   elif t.group()=='}':
    depth-=1
    if depth==0:
     end=t.end();break
  while re.match(r'\s*catch\s*\(',s[end:]):
   b=s.index('{',end);depth=0
   for t in tokens.finditer(s,b):
    if t.group()=='{':depth+=1
    elif t.group()=='}':
     depth-=1
     if depth==0:end=t.end();break
  removed.append({'signature':signature,'lines':s[a:end].count('\n')+1});s=s[:a]+s[end:].lstrip('\n')
 return s
def edit(file,fn):
 p=root/file;s=p.read_text();p.write_text(fn(s))
def store(s):
 s=remove(s,'KisPageStore::reserveManagedRange(')
 a=s.index('KisPageMutationSession KisPageStore::beginMutation(const KisPageTransaction &transaction, QString *error)')
 b=s.index('KisCpuWriteGuard KisPageMutationSession::beginWrite(',a)
 old=s[a:b]
 body=old[old.index('    QMutexLocker lock(&d->mutex);'):]
 body=body.replace('if (!candidate) candidate = Scope::create(d.data());','candidate = Scope::create(d.data());')
 body=re.sub(r'    auto bound = execution \?.*?;\n','',body,flags=re.S)
 x=body.index('    if (execution) {');y=body.index('    if (!d->writeCoordinator.beginSessionActivity',x);body=body[:x]+body[y:]
 x=body.index('    if (bound) {');y=body.index('    result.d = std::move(candidate);',x);body=body[:x]+body[y:]
 s=s[:a]+'''KisPageMutationSession KisPageStore::beginMutation(const KisPageTransaction &transaction, QString *error) try
{
    KisPageMutationSession result;
    boost::intrusive_ptr<KisPageMutationSession::Private> candidate;
'''+body+s[b:]
 for sig in ['KisPageStore::resolvePagePresenceInto(', 'KisCapturedReadView::selectReadWindow(']:s=remove(s,sig)
 s=s.replace('create(KisPageStore::Private *owner, size_t initialCount = 0)', 'create(KisPageStore::Private *owner)')
 s=s.replace('KisPageMutationSession::Private::create(KisPageStore::Private *owner, size_t initialCount)', 'KisPageMutationSession::Private::create(KisPageStore::Private *owner)')
 s=s.replace('    using Execution = KisPageMutationExecution::Private;\n    static_assert(alignof(Private) >= alignof(Execution));\n','')
 x=s.index('    // Only the fixed one-entry execution shares the control allocation.');y=s.index('    void *raw = nullptr;',x);s=s[:x]+s[y:]
 s=s.replace('sizeof(Private) + extra, alignof(Private)', 'sizeof(Private), alignof(Private)')
 s=s.replace('    scope->initialExecutionStorage = extra ? scope + 1 : nullptr;\n    scope->initialExecutionCount = extra ? initialCount : 0;\n','')
 s=re.sub(r'^.*initialExecution(?:Storage|Count) = (?:nullptr|0);[^\n]*\n','',s,flags=re.M)
 s=s.replace('        bool embedded = false;\n','').replace('    bool embedded = false;\n','').replace('        value->embedded = embedded;\n','')
 x=s.index('            if (scope->initialExecutionStorage &&');y=s.index('scope->executionStorage && scope->executionCapacity >= bytes)',x);s=s[:x]+'            if ('+s[y:]
 s=s.replace('    const bool embedded = execution->embedded;\n','')
 x=s.index('    if (embedded) {');y=s.index('    if (scope->state',x);s=s[:x]+s[y:]
 return s
edit('libs/image/pagestore/KisPageStore.cpp',store)
def header(s):
 s=re.sub(r'    // Adapter-only scratch prepared before pixels\..*?    // Internal finite selection\.', '    // Internal finite selection.',s,flags=re.S)
 s=re.sub(r'^    void selectReadWindow\([^;]+;\n','',s,flags=re.M)
 return s
edit('libs/image/pagestore/KisPageStore.h',header)
def tests(s):
 old='''        auto range = f.store->reserveManagedRange({1}, pages, false, nullptr, &f.error, true);
        return f.store->beginMutation(tx, std::move(range), nullptr, &f.error);'''
 new='''        auto scope = f.begin(tx);
        auto declaration = scope.borrowExecution({1}, pages, &f.error);
        Q_ASSERT(declaration.isActive());
        declaration.finish();
        return scope;''';assert old in s;s=s.replace(old,new)
 old='''        QVERIFY(f.store->resolvePagePresenceInto(
            {1}, pages, view, present.data(), present.size()));'''
 new='''        for (qsizetype i = 0; i < pages.size(); ++i) {
            KisPageVersion version;
            QVERIFY(f.store->resolvePageVersion({{1}, pages[i]}, view, &version));
            present[i] = !version.isDefaultPixel();
        }''';assert old in s;s=s.replace(old,new)
 x=s.index('    present.resize(pages.size());',s.index('    QCOMPARE(bindings, bindingsAfterCommit);',s.index('void KisPageStoreCpuMutationTest::metadataPresenceUsesCanonicalSelector()')));y=s.index('    query({}, {0, 1, 1});',x)
 s=s[:x]+'''    KisPageVersion version;
    QVERIFY(!f.store->resolvePageVersion({{1}, pages[0]}, overlay, &version));
    QVERIFY(!f.store->resolvePageVersion({{999}, pages[0]}, {}, &version));
    QVERIFY(!f.store->resolvePageVersion({{1}, pages[0]}, {}, nullptr));
'''+s[y:];return s
edit('libs/image/tests/KisPageStoreCpuMutationTest.cpp',tests)
def provider(s):
 for sig in ['KisTiles3PageReplicaProvider::sourceMatchesReadGuard(', 'KisTiles3PageReplicaProvider::readCacheMatchesVersion(', 'KisTiles3PageReplicaProvider::prepareTileReadCache(']:s=remove(s,sig)
 s=s.replace('    bool matchesVersion(const KisPageVersion &version) const\n    { return m_binding && m_binding->matchesReadIdentity(m_expected, version); }\n','')
 s=s.replace('KisTileData *tile, TileLease reuse, bool pin)', 'KisTileData *tile, TileLease reuse)').replace('if (pin && cache->repinRead()', 'if (cache->repinRead()').replace('std::move(reuse), true);','std::move(reuse));')
 return s
edit('libs/image/pagestore/KisTiles3PageReplicaProvider.cpp',provider)
def ph(s):
 for method in ['sourceMatchesReadGuard','readCacheMatchesVersion','prepareTileReadCache']:
  s=re.sub(r'^    (?:bool|TileLease) '+method+r'\([^;]+;\n','',s,flags=re.M)
 return s
edit('libs/image/pagestore/KisTiles3PageReplicaProvider.h',ph)
edit('libs/image/pagestore/native/KisNativeResultResource.cpp',lambda s:remove(s,'KisNativeResultProtocol::Impl::reclassifyUnselected('))
edit('libs/image/pagestore/native/KisNativeResultState_p.h',lambda s:s.replace('    void reclassifyUnselected(Resource *) noexcept;\n',''))
# configureLimits is a public protocol capability, not a former adapter bridge;
# retain it until its contract is explicitly changed, despite current tests not using it.
(Path(__file__).parent/'REMOVED_ADAPTER_83.json').write_text(json.dumps(removed,indent=2)+'\n')
