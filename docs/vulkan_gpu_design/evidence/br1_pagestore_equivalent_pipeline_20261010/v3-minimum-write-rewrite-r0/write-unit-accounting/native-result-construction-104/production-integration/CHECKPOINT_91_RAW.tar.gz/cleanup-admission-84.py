from pathlib import Path
import re,json
exec((Path(__file__).parent/'cleanup-adapter-83.py').read_text().split('def store(s):')[0])
def header(s):
 s=s.replace('NativeSession, ManagedRange, LegacyAdapter, GenericWrite','NativeSession, GenericWrite')
 s=re.sub(r'    // Non-owning adapter fact.*?    void \*adapterLocation = nullptr;\n','',s,flags=re.S)
 s=re.sub(r'^    void \*&adapterLocation\(\) const[^\n]*\n','',s,flags=re.M)
 a=s.index('    enum class Conflict : quint8 {');b=s.index('    enum class Result',a);s=s[:a]+s[b:]
 a=s.index('    class LegacyInspection final');b=s.index('    class ClaimSet final',a);s=s[:a]+s[b:]
 a=s.index('        // No further execution/delivery');b=s.index('        void release() noexcept;',a);s=s[:a]+s[b:]
 a=s.index('    Conflict conflictLocked(');b=s.index('    // Growth temporarily releases ownerLock.',a);s=s[:a]+'    bool pageClaimedLocked(const KisPageKey &) const;\n'+s[b:]
 s=s.replace('''QMutexLocker<QMutex> &, QString *error,
                  ClaimOrigin origin = ClaimOrigin::NativeSession,
                  const LegacyInspection *inspection = nullptr);''','''QMutexLocker<QMutex> &, QString *error);''')
 s=s.replace('''QMutexLocker<QMutex> &, QString *error,
                  ClaimOrigin origin = ClaimOrigin::NativeSession);''','''QMutexLocker<QMutex> &, QString *error);''')
 s=s.replace('QString *, ClaimOrigin);','QString *);').replace('    static Conflict classify(const KisPageWriteClaim *, Qt::HANDLE requester);\n','').replace('void attach(ClaimSet &, KisPageWriteClaim &, ClaimOrigin);','void attach(ClaimSet &, KisPageWriteClaim &);')
 return s
edit('libs/image/pagestore/KisPageWriteCoordinator_p.h',header)
def cpp(s):
 for sig in ['KisPageWriteAdmission::ClaimSet::retainClaimsForTerminal(', 'KisPageWriteAdmission::classify(', 'KisPageWriteAdmission::conflictLocked(', 'KisPageWriteAdmission::inspectLegacyClaimLocked(']:s=remove(s,sig)
 s=s.replace('KisPageWriteClaim &claim, ClaimOrigin origin)', 'KisPageWriteClaim &claim)').replace('Q_ASSERT(!claim.token && origin != ClaimOrigin::GenericWrite);','Q_ASSERT(!claim.token);').replace('claim.origin = origin;','claim.origin = ClaimOrigin::NativeSession;')
 s=s.replace('QString *error, ClaimOrigin origin, const LegacyInspection *inspection)', 'QString *error)').replace('QString *error, ClaimOrigin origin)', 'QString *error)')
 s=s.replace('!valid(claims) || origin == ClaimOrigin::GenericWrite', '!valid(claims)')
 s=s.replace('attach(claims, *entry.writeClaim, origin)', 'attach(claims, *entry.writeClaim)')
 a=s.index('    if (inspection) {');b=s.index('    return claimEntries(',a);s=s[:a]+s[b:]
 s=s.replace('lock, error, origin)', 'lock, error)').replace('lock, error, ClaimOrigin::NativeSession)', 'lock, error)')
 s=s.replace('''    // Original PageControls form the owner's chain, including abandoned
    // terminal scopes. No row lookup, key rehash or global-table scan remains.''','''    // Original PageControls form this live owner's chain. Release precedes
    // write-row destruction and needs no global-table scan.''')
 return s
edit('libs/image/pagestore/KisPageWriteCoordinator.cpp',cpp)
def store(s):
 s=s.replace('Q_ASSERT(!admission.isValid() || admission.isTerminal());','Q_ASSERT(!admission.isValid());')
 s=s.replace('''                          KisPageWriteAdmission::ClaimOrigin origin,
                          QString *error = nullptr, KisMutationPageEntry *entry = nullptr,
                          const KisPageWriteAdmission::LegacyInspection *location = nullptr) try''','''                          QString *error = nullptr, KisMutationPageEntry *entry = nullptr) try''')
 s=s.replace('lock, error, origin, location)', 'lock, error)').replace('lock, KisPageWriteAdmission::ClaimOrigin::NativeSession, ', 'lock, ')
 return s
edit('libs/image/pagestore/KisPageStore.cpp',store)
def tests(s):
 s=s.replace('legacyInspectionRevalidatesOriginalClaim','claimRejectsForeignOrContendedRows').replace('terminalAdmissionOutlivesWriteRows','admissionReleasePrecedesWriteRows')
 s=s.replace(', KisPageWriteAdmission::ClaimOrigin::ManagedRange','')
 s=re.sub(r'    QCOMPARE\(admission\.conflictLocked\([^;]+;\n','',s)
 s=s.replace('''lock, &error,
        KisPageWriteAdmission::ClaimOrigin::LegacyAdapter)''','''lock, &error)''')
 s=s.replace('''    claims.retainClaimsForTerminal();
    writes = KisMutationWriteSet();
    auto terminal = std::move(claims);
    terminal.releaseLocked();''','''    auto terminal = std::move(claims);
    terminal.releaseLocked();
    writes = KisMutationWriteSet();''')
 a=s.index('void KisPageStoreReferenceTest::claimRejectsForeignOrContendedRows()');b=s.index('void KisPageStoreReferenceTest::admissionReleasePrecedesWriteRows()',a)
 s=s[:a]+'''void KisPageStoreReferenceTest::claimRejectsForeignOrContendedRows()
{
    KisPageMetadataCoordinator metadata, foreignMetadata;
    QVERIFY(metadata.configure(1)); QVERIFY(foreignMetadata.configure(1));
    QMutex mutex, foreignMutex; KisPageWaitCondition changed, foreignChanged;
    KisPageWriteAdmission admission(metadata, mutex, changed), foreign(foreignMetadata, foreignMutex, foreignChanged);
    KisMutationWriteSet rows, competingRows;
    KisPageWriteIntent input; input.key = pageKey(0);
    auto &entry = rows.getOrCreate(input); competingRows.getOrCreate(input);
    auto claims = admission.beginClaimSet(rows), competing = admission.beginClaimSet(competingRows);
    QString error; QMutexLocker lock(&mutex);
    QVERIFY(admission.claimDirectLocked(input.key, 91, lock, &error));
    QVERIFY(!admission.claimOne(claims, rows.handleOf(entry), lock, &error));
    QCOMPARE(admission.activeGenericClaimCountLocked(), qsizetype(1));
    admission.releaseDirectLocked(input.key, 91);
    {
        QMutexLocker foreignLock(&foreignMutex);
        QVERIFY(!foreign.claimOne(claims, rows.handleOf(entry), foreignLock, &error));
    }
    QVERIFY(admission.claimOne(claims, rows.handleOf(entry), lock, &error));
    QVERIFY(admission.ownsEntryLocked(claims, entry));
    QVERIFY(!admission.claimOne(competing, competingRows.handleAt(0), lock, &error));
    claims.releaseLocked();
    QVERIFY(admission.claimOne(competing, competingRows.handleAt(0), lock, &error));
    competing.releaseLocked();
    QCOMPARE(admission.activeNativeClaimCountLocked(), qsizetype(0));
    QCOMPARE(admission.activeGenericClaimCountLocked(), qsizetype(0));
}

'''+s[b:]
 s=s.replace('    claims.retainClaimsForTerminal();\n','').replace('    QVERIFY(terminal.isTerminal());\n','')
 s=s.replace('''    writes = KisMutationWriteSet(); // The terminal owner cannot borrow these rows.''','''    QVERIFY(admission.ownsClaimSetLocked(terminal));
    terminal.releaseLocked(); // No adapter tail retains claims after rows end.
    writes = KisMutationWriteSet();''')
 s=s.replace('    QVERIFY(admission.ownsClaimLocked(terminal, pageKey(0)));','    QVERIFY(!admission.ownsClaimLocked(terminal, pageKey(0)));')
 s=s.replace('''    QCOMPARE(admission.claimAll(next, lock, &error), KisPageWriteAdmission::Result::Contended);
    terminal.releaseLocked();''','''    QVERIFY(!admission.pageClaimedLocked(pageKey(0)));
    terminal.releaseLocked();''')
 return s
edit('libs/image/tests/KisPageStoreReferenceTest.cpp',tests)
(Path(__file__).parent/'REMOVED_ADMISSION_84.json').write_text(json.dumps(removed,indent=2)+'\n')
