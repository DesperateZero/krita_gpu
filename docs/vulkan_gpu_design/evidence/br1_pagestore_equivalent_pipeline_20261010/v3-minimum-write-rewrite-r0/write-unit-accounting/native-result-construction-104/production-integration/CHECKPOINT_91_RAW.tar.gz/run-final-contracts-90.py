from pathlib import Path
import os,json,subprocess,hashlib,re,time
p=Path(__file__).resolve().parent
out=p/'final-contracts-90';out.mkdir(exist_ok=True)
env=os.environ.copy();env.update(QT_QPA_PLATFORM='offscreen',QT_HASH_SEED='0',KIS_BR1_SEED='20261104',KIS_TEST_PREFIX_PATH='/Users/apple/krita_gpu/krita/_install',QT_PLUGIN_PATH='/Users/apple/krita_gpu/krita/_install/plugins',KIS_TEST_PLUGIN_PATH='/Users/apple/krita_gpu/krita/_build-br0-cpu/bin',DYLD_LIBRARY_PATH=str(p/'build/bin')+':/Users/apple/krita_gpu/krita/_build-br0-cpu/bin',DYLD_PRINT_LIBRARIES='1')
identity={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=p/'source',text=True).strip(),'diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff','HEAD'],cwd=p/'source')).hexdigest(),'image_sha256':hashlib.sha256((p/'build/bin/libkritaimage.21.0.0.dylib').read_bytes()).hexdigest(),'environment':{k:v for k,v in env.items() if k.startswith(('QT_','KIS_','DYLD_'))}}
(out/'IDENTITY.json').write_text(json.dumps(identity,indent=2))
manager=json.loads((p/'manager-complete-64.json').read_text())['command'][3:]
targets=[('NativeResultProtocolContractTest.app/Contents/MacOS/NativeResultProtocolContractTest',[]),('kis_tiled_data_manager_test',manager+['stressTest','stressTestLazyCopying','stressTestExtentsColumn'])]
targets += [(s,[]) for s in ['KisCompletionRegistryTest','KisPageStoreFoundationTest','KisPageStorePhysicalClaimTest','KisPageStoreCpuMutationTest','KisPageStoreResidentReadTest','KisPageStoreReferenceTest','KisPageStoreReadBaselineTest','kis_tile_data_store_test','kis_strokes_queue_test']]
targets += [('FreehandStrokeTest',['testPersistentAutoBrushStroke','testPersistentAutoBrushStrokeCancelled','testPersistentAutoBrushStrokeFailure','testPersistentAutoBrushStrokePressure','testPersistentAutoBrushStrokePressureCancelled'])]
# Painter public consumers: reuse the actual migrated product selectors.
prior=json.loads((p/'painter-19.json').read_text());targets += [('kis_painter_test',prior['command'][3:])]
records=[]
for arch in ['arm64','x86_64']:
 for target,names in targets:
  name=Path(target).name;log=out/(name+'-'+arch+'.log');cmd=['arch','-'+arch,'/usr/bin/env',*[k+'='+v for k,v in env.items() if k.startswith(('QT_','KIS_','DYLD_'))],str(p/'build/bin'/target),*names]
  rec={'target':name,'arch':arch,'command':cmd,'timeout_seconds':90,'log':log.name};start=time.monotonic()
  with log.open('w') as f:
   child=subprocess.Popen(cmd,cwd=p,env=env,stdout=f,stderr=subprocess.STDOUT);rec['pid']=child.pid
   try:rec['exit']=child.wait(timeout=90)
   except subprocess.TimeoutExpired:
    child.kill()
    try:child.wait(timeout=5);rec['exit']='TIMEOUT_KILLED_REAPED'
    except subprocess.TimeoutExpired:rec['exit']='TIMEOUT_KILL_SENT_OS_REAP_PENDING'
  s=log.read_text();rec['seconds']=time.monotonic()-start;rec['totals']=re.findall(r'Totals:.*',s);rec['native_ok']='NATIVE104_CONTRACT_OK' in s;rec['loaded_image']=sorted(set(re.findall(r'dyld[^\n]*libkritaimage[^\n]*',s)))
  records.append(rec);(out/'RESULTS.json').write_text(json.dumps(records,indent=2));print(arch,name,rec['exit'],rec['totals'],rec['native_ok'],flush=True)
  if rec['exit'] != 0 or not any(str(p/'build/bin/libkritaimage') in line for line in rec['loaded_image']) or (name == 'NativeResultProtocolContractTest' and not rec['native_ok']) or (name != 'NativeResultProtocolContractTest' and (not rec['totals'] or not all('0 failed' in line for line in rec['totals']))):raise SystemExit(1)
