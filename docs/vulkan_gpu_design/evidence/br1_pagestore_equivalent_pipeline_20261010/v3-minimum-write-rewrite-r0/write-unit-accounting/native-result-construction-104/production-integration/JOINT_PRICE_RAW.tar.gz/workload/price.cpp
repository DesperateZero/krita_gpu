/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <QApplication>
#include <QByteArray>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <cstdio>
#include <ctime>
#include <dlfcn.h>
#include <memory>
#include <os/signpost.h>
#include "tiles3/kis_tiled_data_manager.h"
#include "pagestore/KisPageStoreReclamation_p.h"
#ifdef NATIVE104
#include "KisNativeResultProtocol.h"
#include "pagestore/KisMutationStorage_p.h"
#endif

static void check(bool ok) { if (!ok) { std::fprintf(stderr, "COVERAGE_ASSERT_FAILED\n"); std::abort(); } }
static const quint8 *bytes(const QByteArray &v) { return reinterpret_cast<const quint8 *>(v.constData()); }
struct Stamp { qint64 wall, cpu, thread; };
static Stamp now() {
    timespec w{}, c{}, t{};
    check(!clock_gettime(CLOCK_MONOTONIC, &w) && !clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &c) && !clock_gettime(CLOCK_THREAD_CPUTIME_ID, &t));
    return {w.tv_sec * 1000000000LL + w.tv_nsec, c.tv_sec * 1000000000LL + c.tv_nsec, t.tv_sec * 1000000000LL + t.tv_nsec};
}
#include "slow_process_counters.h"
#ifdef NATIVE104
struct NativeHistory : KisShared, KisPageProcessStorageObject {
    KisNativeResultProtocol::Snapshot before, after;
};
using History = KisSharedPtr<NativeHistory>;
class Manager : public KisTiledDataManager {
public:
    std::unique_ptr<KisNativeResultProtocol> protocol;
    History history;
    Manager(quint32 bpp, const quint8 *pixel)
        : KisTiledDataManager(bpp, pixel, SelectionAuthority::ExternalProtocol) {
        KisSurfaceEpochState s;
        s.surface = {1}; s.logicalPageExtent = QSize(64, 64);
        s.layoutRevision = s.rowAlignment = s.defaultPixelRevision = s.extentRevision = 1;
        auto &f = s.format;
        f.formatId = 104; f.colorModelId = "RAW"; f.colorDepthId = "U8";
        f.profileFingerprint = "native104"; f.channelOrder = "raw"; f.packing = "interleaved";
        f.defaultPixel = QByteArray(reinterpret_cast<const char *>(pixel), bpp);
        f.channelCount = f.pixelStride = bpp; f.pixelAlignment = 1;
        f.hasAlpha = false; f.alphaSemantic = KisSurfaceAlphaSemantic::Opaque;
        f.endianness = KisSurfaceEndianness::NativeEndian; f.codecVersion = 1;
        protocol = std::make_unique<KisNativeResultProtocol>(*this, s.allocationDescriptor());
    }
    ~Manager() { history.clear(); protocol.reset(); }
    void writeBytes(const quint8 *v, int x, int y, int w, int h) {
        check(protocol->write(v, QRect(x, y, w, h), qint64(w) * pixelSize()));
    }
    void readBytes(quint8 *v, int x, int y, int w, int h) {
        check(protocol->readCurrent(v, QRect(x, y, w, h), qint64(w) * pixelSize()));
    }
    void commit() { if (history && !history->after) { history->after = protocol->capture(); check(bool(history->after)); } }
    History getMemento() { history = new NativeHistory; history->before = protocol->capture(); check(bool(history->before)); return history; }
    void rollback(History h) { commit(); check(protocol->restore(h->before)); }
    void rollforward(History h) { check(protocol->restore(h->after)); }
    void purgeHistory(History) { history.clear(); }
};
#else
using Manager = KisTiledDataManager;
using History = KisMementoSP;
#endif

int main(int argc, char **argv) {
    configureKernelCounters(); QApplication app(argc, argv);
    struct SelfCounts { uint64_t instructions, cycles, user, system; };
    const auto self = reinterpret_cast<int (*)(unsigned, void *, size_t)>(dlsym(RTLD_DEFAULT, "thread_selfcounts"));
    const int mode = qEnvironmentVariableIntValue("BR1_MODE52");
    if (mode) check(self != nullptr);
    const int id = qEnvironmentVariableIsSet("BR1_CASE") ? qEnvironmentVariableIntValue("BR1_CASE") : 7;
    const int side = qEnvironmentVariableIsSet("BR1_SIDE104") ? qEnvironmentVariableIntValue("BR1_SIDE104") : ((id & 1) ? 256 : 64);
    const int writes = qEnvironmentVariableIsSet("BR1_WRITES104") ? qEnvironmentVariableIntValue("BR1_WRITES104") : ((id & 2) ? 16 : 1);
    const int bpp = qEnvironmentVariableIsSet("BR1_BPP104") ? qEnvironmentVariableIntValue("BR1_BPP104") : 4;
    const int lives = qEnvironmentVariableIsSet("BR1_LIFETIMES") ? qEnvironmentVariableIntValue("BR1_LIFETIMES") : 4;
    const bool history = id & 4;
    check(side > 0 && side % 64 == 0 && writes > 0 && lives > 0);
    QByteArray blank(bpp, 0), a(side * side * bpp, char(0x19)), b(a.size(), char(0x53)), c(a.size(), char(0x6d)), out(a.size(), 0);
    uint64_t instructions[7]{}, calls[7]{}; Stamp times[7]{};
#ifdef NR104_CENSUS
    KisNativeResultProtocol::Counts warm{};
#endif
    const char *names[] = {"setup", "write", "read", "finish", "undo", "redo", "teardown"};
    const bool tracing = qEnvironmentVariableIsSet("BR1_TRACE");
    auto log = tracing ? os_log_create("org.krita.br1.budget", "PointsOfInterest") : OS_LOG_DISABLED;
    auto measure = [&](int phase, auto &&fn) {
        SelfCounts start{}, end{};
        if (tracing) os_signpost_interval_begin(log, os_signpost_id_t(phase + 100), "Native104Phase", "phase=%d", phase);
        if (mode == 2) check(!self(3, &start, sizeof start));
        const auto begin = now(); fn(); const auto done = now();
        if (mode == 2) { check(!self(3, &end, sizeof end)); instructions[phase] += end.instructions - start.instructions; ++calls[phase]; }
        times[phase].wall += done.wall - begin.wall; times[phase].cpu += done.cpu - begin.cpu; times[phase].thread += done.thread - begin.thread;
        if (tracing) os_signpost_interval_end(log, os_signpost_id_t(phase + 100), "Native104Phase", "phase=%d", phase);
    };
    if (tracing) os_signpost_interval_begin(log, os_signpost_id_t(id + 1), "BudgetCase", "case=%d", id);
    const auto kernelStart = kernelSnapshot(); SelfCounts outerStart{}, outerEnd{};
    if (mode) check(!self(3, &outerStart, sizeof outerStart)); const auto start = now();
    for (int life = 0; life < lives; ++life) {
        std::unique_ptr<Manager> dm; History memento;
        measure(0, [&] { dm = std::make_unique<Manager>(bpp, bytes(blank)); dm->writeBytes(bytes(a), 0, 0, side, side); dm->commit(); if (history) memento = dm->getMemento(); });
#ifdef NR104_CENSUS
        const auto before = dm->protocol->counts();
#endif
        const QByteArray *last = &a;
        for (int i = 0; i < writes; ++i) {
            last = i % 2 ? &c : &b;
            measure(1, [&] { dm->writeBytes(bytes(*last), 0, 0, side, side); });
            measure(2, [&] { dm->readBytes(reinterpret_cast<quint8 *>(out.data()), 0, 0, side, side); }); check(out == *last);
        }
#ifdef NR104_CENSUS
        const auto after = dm->protocol->counts();
        warm.fresh += after.fresh - before.fresh; warm.handoff += after.handoff - before.handoff;
        warm.results += after.results - before.results; warm.retainedEdges += after.retainedEdges - before.retainedEdges;
#endif
        measure(3, [&] { dm->commit(); });
        if (history) {
            measure(4, [&] { dm->rollback(memento); dm->readBytes(reinterpret_cast<quint8 *>(out.data()), 0, 0, side, side); }); check(out == a);
            measure(5, [&] { dm->rollforward(memento); dm->readBytes(reinterpret_cast<quint8 *>(out.data()), 0, 0, side, side); }); check(out == *last);
        }
        measure(6, [&] { if (memento) { dm->purgeHistory(memento); memento.clear(); } dm.reset(); });
    }
    const auto body = now(); kisDrainPageStoreReclamation(); const auto end = now();
    if (mode) check(!self(3, &outerEnd, sizeof outerEnd)); const auto kernelEnd = kernelSnapshot();
    if (tracing) os_signpost_interval_end(log, os_signpost_id_t(id + 1), "BudgetCase", "case=%d", id);
    QJsonObject row{{"case", id}, {"bpp", bpp}, {"pages", side * side / 4096}, {"writes", writes}, {"history", history}, {"lifetimes", lives},
        {"accepted", true}, {"semantic_ok", true}, {"mode52", mode}, {"body_cpu_ns", body.cpu - start.cpu}, {"tail_cpu_ns", end.cpu - body.cpu},
        {"process_ns", end.cpu - start.cpu}, {"foreground_ns", end.thread - start.thread}, {"wall_ns", end.wall - start.wall}};
    if (mode) row["main_instructions"] = double(outerEnd.instructions - outerStart.instructions);
    if (mode == 2) {
        QJsonArray measured, phaseCalls;
        for (int i = 0; i < 7; ++i) { measured.append(double(instructions[i])); phaseCalls.append(double(calls[i])); }
        row["phase_main_instructions_raw"] = measured; row["phase_calls"] = phaseCalls;
        uint64_t empty = 0;
        for (int n = 0; n < 128; ++n) { SelfCounts a{}, b{}; check(!self(3, &a, sizeof a)); const auto x = now(); const auto y = now(); check(!self(3, &b, sizeof b)); empty += b.instructions - a.instructions; asm volatile("" : : "g"(x.wall), "g"(y.wall) : "memory"); }
        row["empty_replays"] = 128; row["empty_main_instructions_raw"] = double(empty);
    }
    row["kernel"] = kernelDelta(kernelStart, kernelEnd);
#ifdef NR104_CENSUS
    row["census"] = QJsonObject{{"fresh", double(warm.fresh)}, {"handoff", double(warm.handoff)},
        {"results", double(warm.results)}, {"retained_edges", double(warm.retainedEdges)}};
#endif
    for (int i = 0; i < 7; ++i) row[names[i]] = QJsonObject{{"cpu_ns", times[i].cpu}, {"thread_cpu_ns", times[i].thread}, {"wall_ns", times[i].wall}};
    std::fprintf(stderr, "BR1_COVERAGE %s\nNATIVE104_PRICE_COMPLETE\n", QJsonDocument(row).toJson(QJsonDocument::Compact).constData());
}
