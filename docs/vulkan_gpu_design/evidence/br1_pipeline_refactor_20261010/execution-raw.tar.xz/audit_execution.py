"""Independent event/count closure, literal bootstrap and text evidence archive."""
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import random
import re
import statistics as st
import subprocess
import tarfile

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3];PRODUCT=ROOT/'krita';RUN=HERE/'execution-r2/observations'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=PRODUCT,text=True).strip()
assert head=='11c6895ddfeae074df727c76dcbf9e12988479ee'
assert not subprocess.check_output(['git','diff','--binary','HEAD'],cwd=PRODUCT)
library=PRODUCT/'_build-br0-cpu/bin/libkritaimage.21.0.0.dylib'
assert sha(library)=='91e962c2c43379697b13f37a2ee388d408440c67f3e21458e75c70dab4b21b38'
identity=json.loads((RUN/'identity-final.json').read_text());assert all(sha(p)==d for p,d in identity['hashes'].items())
summary=json.loads((HERE/'execution-summary.json').read_text())
assert all(sha(HERE/p)==d for p,d in summary['raw_hashes'].items())
old_checks={};shared_checks={}
for directory in ('net-ledger-r1/observations','flow-census-r1'):
    old=json.loads((HERE/directory/'identity-final.json').read_text())['hashes']
    for p,d in old.items():
        path=Path(p)
        if sha(path)!=d:
            assert path.name in ('NET_PROTOCOL.md','run_net_ledger.py')
            path=HERE/'net-ledger-r1/observations'/path.name
        assert sha(path)==d
    shared=set(old)&set(identity['hashes']);assert all(old[p]==identity['hashes'][p] for p in shared)
    old_checks[directory]=len(old);shared_checks[directory]=len(shared)
rows=json.loads((RUN/'results.json').read_text())
assert len(rows)==36 and all(r['passed'] and r['reaped'] and not r['timed_out'] for r in rows)
assert json.loads((RUN/'running.json').read_text())==dict(state='complete',processes=36)
closure_checks=0;flow_checks=0;job_checks=0;phase_count=0;locks=0;events_count=0
for r in rows:
    dest=RUN/f"{r['index']:02}-{r['kind']}-{r['side']}-mode{r['mode']}"
    raw=(dest/'fixture.log').read_text()
    es=[json.loads(s) for s in re.findall(r'BR1_EXEC_EVENT (\{[^\n]+\})',raw)]
    assert es==json.loads((dest/'events.json').read_text())
    if r['mode']==0:assert not es and not r['buckets'];continue
    for c in range(8):
        selected=[e for e in es if e['case']==c]
        en=sorted((e for e in selected if e['kind']=='enqueue'),key=lambda e:e['start'][0])
        de=sorted((e for e in selected if e['kind']=='dequeue'),key=lambda e:e['start'][0])
        jobs=sorted((e for e in selected if e['kind']=='job'),key=lambda e:e['start'][0])
        assert len(en)==len(de)==len(jobs)
        for a,d,j in zip(en,de,jobs):
            assert (a['key'],a['name'])==(d['key'],d['name'])==(j['key'],j['name'])
            assert a['start'][0]<=d['start'][0]<=j['start'][0]<=j['end'][0];job_checks+=1
        for role,kind in [(0,'phase'),(1,'job')]:
            bs=Counter({b['name']:b['count'] for b in r['buckets'] if b['case']==c and b['role']==role})
            ss=[e for e in selected if e['role']==role and e['kind']==kind]
            sums=sum((Counter(e['counts']) for e in ss),Counter())
            if kind=='job':sums.update(e['name'] for e in ss)
            assert bs==sums,(r['index'],c,role,bs-sums,sums-bs);closure_checks+=1
        if r['side']=='current':
            bs=Counter()
            for b in r['buckets']:
                if b['case']==c:bs[b['name']]+=b['count']
            k=16 if c&1 else 1;w=16 if c&2 else 1;fresh=4*k*(w+1)
            for name in ('fresh_accepted','rows','provider_adopted','provider_physical_registered','provider_physical_released',
                'provider_allocation_removed','provider_retire','binding_created','binding_destroyed','owner_backing_installed',
                'owner_backing_removed','owner_physical_installed','owner_physical_removed','proof_installed','proof_revoked',
                'metadata_version_created','retirement_attempt','retirement_succeeded'):
                assert bs[name]==fresh,(r['index'],c,name,bs[name],fresh);flow_checks+=1
            assert bs['free']==fresh+4 and bs['descriptor_prepared']==fresh+4*k
            assert bs['metadata_version_removed']+bs['metadata_final_versions']==fresh
            assert bs['descriptor_removed']+bs['descriptor_final_nodes']==bs['descriptor_installed']==fresh+4*k
            assert bs['pending_ticket_issued']==fresh+8
            flow_checks+=5
            for name in ('history_restarts','history_rescans','history_blocked_pass','history_retry_armed','history_retry_wakeups',
                'retirement_retry_armed','retirement_retry_wakeups'):assert bs[name]==0
        phase_count+=sum(e['kind']=='phase' for e in selected);locks+=sum(e['kind']=='lock' for e in selected);events_count+=len(selected)
rng=random.Random(20261011);draws=[[rng.randrange(4) for _ in range(4)] for _ in range(100000)]
bootstrap_checks=0
for c in ('3','7'):
    for side in ('current','upstream'):
        for name in ('process','foreground','reclaimer'):
            x=summary['cases'][c]['disturbance_ms'][side][name]
            values=sorted(st.median(x['blocks'][i] for i in draw) for draw in draws)
            def q(p):
                t=p*99999;i=int(t);return values[i]+(values[i+1]-values[i])*(t-i)
            assert all(abs(a-b)<1e-12 for a,b in zip(x['ci95'],[q(.025),q(.975)]));bootstrap_checks+=1
plan=HERE.parent/'br1_pagestore_equivalent_pipeline_20261010/PIPELINE_PLAN.md'
section=plan.read_text().split('### 13. 扩大后的修改索引与删除追踪',1)[1].split('### 14.',1)[0]
matrix=[s for s in section.splitlines() if re.match(r'^\| T\d\d\.\d+ ',s)]
assert len(matrix)==33 and all(len(s.split('|'))==8 for s in matrix)
result=dict(product=head,product_changed=False,product_library_sha256=sha(library),successful_processes=36,
    identity_checks=len(identity['hashes']),old_identity_checks=old_checks,shared_unchanged_identity_inputs=shared_checks,
    event_count=events_count,phase_events=phase_count,queue_job_correlations=job_checks,lock_acquisition_events=locks,
    exact_phase_job_counter_closures=closure_checks,lifecycle_identities=flow_checks,literal_bootstrap_checks=bootstrap_checks,
    matrix_rows=33,matrix_columns=6,plan_sha256=sha(plan),target_h0_h1_mechanism_price_qualified=False,
    selected_design=None,legal_net_recoverable_ms=None,
    failures=['r0 unique source anchor rejected before compilation','r1 observer API signatures failed compilation',
        'initial analyzer duplicate keyword rejected before analysis; original saved; same raw runs reanalyzed',
        'H0/H1 observer disturbance gates failed; no data removed or additional runs'])
(HERE/'execution-audit.json').write_text(json.dumps(result,indent=2)+'\n')
paths=[HERE/n for n in ('EXECUTION_PROTOCOL.md','execution_observer.h','execution_events.inc','build_execution.py','run_execution.py',
    'analyze_execution.py','audit_execution.py','execution-summary.json','execution-audit.json')]
for directory in ('execution-r0','execution-r1','execution-r2'):
    paths.extend(p for p in (HERE/directory).rglob('*') if p.is_file() and not p.is_symlink() and p.suffix in ('.md','.py','.cpp','.h','.inc','.json','.log','.diff'))
archive=HERE/'execution-raw.tar.xz';members={}
with tarfile.open(archive,'w:xz') as tar:
    for p in sorted(set(paths)):
        raw=p.read_bytes();name=str(p.relative_to(HERE));info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0
        tar.addfile(info,io.BytesIO(raw));members[name]=dict(bytes=len(raw),sha256=sha(p))
with tarfile.open(archive,'r:xz') as tar:
    assert len(tar.getmembers())==len(members)
    for entry in tar:
        raw=tar.extractfile(entry).read();assert hashlib.sha256(raw).hexdigest()==members[entry.name]['sha256']
manifest=dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=members)
(HERE/'execution-raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(result,indent=2));print('raw members',len(members),'compressed bytes',archive.stat().st_size)
