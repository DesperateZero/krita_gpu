"""Generate and build baseline-only execution derivatives; retain exact diffs."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[3]; PRODUCT=ROOT/'krita'
OUT=HERE/'execution-r2'; OUT.mkdir()
HEAD='11c6895ddfeae074df727c76dcbf9e12988479ee'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=PRODUCT,text=True).strip()==HEAD
assert not subprocess.check_output(['git','diff','--binary','HEAD'],cwd=PRODUCT)
hashes={}; anchors=[]
def read(p):
    hashes[str(p)]=sha(p); return p.read_text()
def replace(t,a,b):
    assert t.count(a)==1,a
    return t.replace(a,b)
def save(p,old,new):
    p.write_text(new)
    p.with_suffix(p.suffix+'.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True))))
for name in ('EXECUTION_PROTOCOL.md','execution_observer.h','execution_events.inc','build_execution.py','run_execution.py'):
    (OUT/name).write_text(read(HERE/name))
(OUT/'net_observer.h').write_text(read(HERE/'net-ledger-r3/net_observer.h'))
original=read(HERE/'net-ledger-r3/net_observer.cpp'); observer=original
observer=observer.replace('#include "net_observer.h"','#include "net_observer.h"\n#include "execution_observer.h"\n#include <pthread/qos.h>')
observer=observer.replace('Buckets=64','Buckets=128')
observer=replace(observer,'Bank banks[Roles];','void execReset();\nvoid execDump();\nBank banks[Roles];')
a=observer.index('extern "C" void *br1_net_enter');b=observer.index('extern "C" void br1_net_begin',a)
observer=observer[:a]+'''extern "C" void *br1_net_enter(const char *name) {
    br1_exec_add(name,1); return nullptr;
}
extern "C" void br1_net_exit(void *) {}
'''+observer[b:]
observer=replace(observer,'    recording.store(true);','    execReset();\n    recording.store(true);')
observer=replace(observer,'    if(errors.load()) std::abort();','    if(errors.load()) std::abort();\n    execDump();')
a=observer.index('extern "C" void br1_net_count')
observer=observer[:a]+'''extern "C" void br1_net_count(const char *name) { br1_exec_add(name,1); }
#include "execution_events.inc"
'''
save(OUT/'net_observer.cpp',original,observer)

original=read(HERE/'net-ledger-r1/foreground_fixture.cpp');fixture=original
fixture=replace(fixture,'    check(netBegin && netEnd && netDrain);','''    using ExecBegin=void *(*)(const char *,const char *,uintptr_t);
    using ExecEnd=void (*)(void *);
    auto execBegin=reinterpret_cast<ExecBegin>(dlsym(RTLD_DEFAULT,"br1_exec_begin"));
    auto execEnd=reinterpret_cast<ExecEnd>(dlsym(RTLD_DEFAULT,"br1_exec_end"));
    check(netBegin && netEnd && netDrain && execBegin && execEnd);''')
fixture=replace(fixture,'        auto measure = [&](int phase, auto &&operation) {','''        uintptr_t operationIndex=0;
        auto measure = [&](int phase, auto &&operation) {
            auto event=execBegin("phase",names[phase],operationIndex++);''')
fixture=replace(fixture,'            if (marker) marker(0);','            if (marker) marker(0);\n            execEnd(event);')
save(OUT/'foreground_fixture.cpp',original,fixture)

for side in ('current','upstream'):
    dest=OUT/side;dest.mkdir()
    build=PRODUCT/'_build-br0-cpu' if side=='current' else ROOT/'build/br1-cp0-20261003/upstream-build'
    old=json.loads(read(HERE/'net-ledger-r1'/side/'commands.json'))
    linkbase=HERE/'flow-census-r1/commands.json' if side=='current' else HERE/'net-ledger-r3/upstream/commands.json'
    link=next(c.copy() for c in json.loads(read(linkbase)) if '-dynamiclib' in c)
    commands=[]
    if side=='current':
        for name in ('KisPageStoreReclamation.cpp','KisPageHistoryCollector.cpp','KisPageRetirementQueue.cpp'):
            original=read(HERE/'net-ledger-r1/current'/name)
            source=read(PRODUCT/'libs/image/pagestore'/name)
            text='#include "execution_observer.h"\n'+original
            if name=='KisPageStoreReclamation.cpp':
                text=replace(text,'        m_lastJob = job;','''        m_lastJob = job;
        br1_exec_point("enqueue",typeid(*job).name(),reinterpret_cast<uintptr_t>(job));''')
                text=replace(text,'            job->next = nullptr;','''            job->next = nullptr;
            br1_exec_point("dequeue",typeid(*job).name(),reinterpret_cast<uintptr_t>(job));''')
                text=replace(text,'                Br1NetScope net_job(typeid(*job).name());','''                Br1NetScope net_job(typeid(*job).name());
                Br1ExecSpan exec_job("job",typeid(*job).name(),reinterpret_cast<uintptr_t>(job));''')
            else:
                pattern=r'QMutexLocker (\w+)\(&(m_ownerMutex|collector->m_ownerMutex)\);' if 'History' in name else r'QMutexLocker (\w+)\(&(m_mutex|queue->m_mutex)\);'
                n=[0]
                def gate(m):
                    n[0]+=1;label=('history_owner' if 'History' in name else 'retirement_queue')+':'+str(n[0])
                    anchors.append(dict(file=name,anchor=m.group(),label=label))
                    return f'auto *exec_lock_{n[0]}=br1_exec_begin("lock","{label}",reinterpret_cast<uintptr_t>(&{m[2]}));\n            {m.group()}\n            br1_exec_end(exec_lock_{n[0]});'
                text=re.sub(pattern,gate,text)
                assert n[0]>0
                changes=[]
                if 'History' in name:
                    changes=[('visitedVersions += quint64(slice.count);','br1_exec_add("history_versions",slice.count);'),
                        ('++m_reachabilityRootsVisited;','br1_net_count("history_roots");'),
                        ('m_reachabilityRootsVisited += quint64(roots.rootsVisited);','br1_exec_add("history_roots",roots.rootsVisited);'),
                        ('++m_pagesVisited;','br1_net_count("history_pages");'),
                        ('++m_reachabilityRestarts;','br1_net_count("history_restarts");'),
                        ('if (m_rescanRequested) {\n        m_rescanRequested = false;','br1_net_count("history_rescans");'),
                        ('++collector->m_retryWakeups;','br1_net_count("history_retry_wakeups");'),
                        ('m_retryScheduled = m_retry.arm(m_retryDelayMs);','if(m_retryScheduled) br1_net_count("history_retry_armed");'),
                        ('return blocked;','if(blocked) br1_net_count("history_blocked_pass");')]
                    # blocked count must occur before the original return.
                    text=replace(text,'    return blocked;','    if(blocked) br1_net_count("history_blocked_pass");\n    return blocked;')
                    changes=changes[:-1]
                else:
                    changes=[('++queue->m_retryWakeups;','br1_net_count("retirement_retry_wakeups");'),
                        ('m_retryScheduled = m_retryTask.arm(m_nextRetryDelayMs);','if(m_retryScheduled) br1_net_count("retirement_retry_armed");'),
                        ('++m_backgroundPasses;','br1_net_count("retirement_background_passes");')]
                    a=text.index('bool KisPageRetirementQueue::retireRecord'); b=text.index('void KisPageRetirementQueue::updatePeaksLocked',a)
                    sub=text[a:b];sub=replace(sub,'    if (!record.provider)','    br1_net_count("retirement_attempt");\n    if (!record.provider)')
                    sub=replace(sub,'    return true;','    br1_net_count("retirement_succeeded");\n    return true;')
                    text=text[:a]+sub+text[b:]
                for a,b in changes:
                    text=replace(text,a,a+'\n        '+b);anchors.append(dict(file=name,anchor=a,addition=b))
            derived=dest/name;save(derived,source,text)
            cmd=next(c.copy() for c in old if '-c' in c and c[c.index('-c')+1].endswith('/'+name))
            obj=str(dest/(name+'.o'));previous=cmd[cmd.index('-o')+1]
            cmd[cmd.index('-o')+1]=obj;cmd[cmd.index('-c')+1]=str(derived);cmd.insert(1,'-I'+str(OUT))
            assert previous in link;link=[obj if t==previous else t for t in link];commands.append(cmd)
    compile=next(c.copy() for c in old if '-c' in c and c[c.index('-c')+1].endswith('/net_observer.cpp'))
    obj=str(dest/'net_observer.o');compile[compile.index('-o')+1]=obj;compile[compile.index('-c')+1]=str(OUT/'net_observer.cpp')
    compile.insert(1,'-I'+str(OUT));commands.append(compile)
    link=[obj if t.endswith('/net_observer.o') else t for t in link];link[link.index('-o')+1]=str(dest/'libkritaimage.21.0.0.dylib');commands.append(link)
    compile=next(c.copy() for c in old if '-c' in c and c[c.index('-c')+1].endswith('/foreground_fixture.cpp'))
    prevobj=compile[compile.index('-o')+1];obj=str(dest/'storage.o');compile[compile.index('-o')+1]=obj
    compile[compile.index('-c')+1]=str(OUT/'foreground_fixture.cpp');commands.append(compile)
    fixturelink=next(c.copy() for c in old if '-o' in c and c[c.index('-o')+1].endswith('/storage'))
    fixturelink=[obj if t==prevobj else t for t in fixturelink];fixturelink[fixturelink.index('-o')+1]=str(dest/'storage');commands.append(fixturelink)
    for command in commands:
        for token in command:
            if token.endswith('.o') and not token.startswith(str(OUT)):
                p=Path(token) if Path(token).is_absolute() else build/token;hashes[str(p)]=sha(p)
    (dest/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    for i,command in enumerate(commands):
        print(side,i,flush=True)
        with (dest/f'build-{i}.log').open('x') as log:subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
    (dest/'libkritaimage.21.dylib').symlink_to('libkritaimage.21.0.0.dylib')
(OUT/'anchors.json').write_text(json.dumps(anchors,indent=2)+'\n')
for p in OUT.rglob('*'):
    if p.is_file() and not p.is_symlink():hashes[str(p)]=sha(p)
(OUT/'identity.json').write_text(json.dumps(dict(head=HEAD,hashes=hashes),indent=2)+'\n')
print('Baseline execution observer built.',flush=True)
