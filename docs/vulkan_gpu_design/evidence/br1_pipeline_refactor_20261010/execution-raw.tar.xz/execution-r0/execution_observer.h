#pragma once
#include <cstdint>
extern "C" {
__attribute__((visibility("default"))) void *br1_exec_begin(const char *, const char *, uintptr_t);
__attribute__((visibility("default"))) void br1_exec_end(void *);
__attribute__((visibility("default"))) void br1_exec_point(const char *, const char *, uintptr_t);
__attribute__((visibility("default"))) void br1_exec_add(const char *, unsigned long long);
}
struct Br1ExecSpan {
    void *handle;
    Br1ExecSpan(const char *kind, const char *name, uintptr_t key=0)
        : handle(br1_exec_begin(kind,name,key)) {}
    ~Br1ExecSpan() { br1_exec_end(handle); }
};
