// Same public storage operations compiled against both implementations.
#include <QApplication>
#include <QByteArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QVector>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <memory>
#include <ctime>
#include <sys/resource.h>
#include "tiles3/kis_tiled_data_manager.h"

struct Stamp { long long wall, cpu, thread; };
static Stamp now() {
    timespec w{}, c{}, th{};
    if (clock_gettime(CLOCK_THREAD_CPUTIME_ID, &th) || clock_gettime(CLOCK_MONOTONIC, &w) || clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &c)) std::abort();
    return {w.tv_sec * 1000000000LL + w.tv_nsec, c.tv_sec * 1000000000LL + c.tv_nsec, th.tv_sec * 1000000000LL + th.tv_nsec};
}
static void check(bool value) { if (!value) { std::fprintf(stderr,"STORAGE_ASSERT_FAILED\n"); std::abort(); } }
using Marker = void (*)(int);
using Action = void (*)();

int main(int argc, char **argv) {
    QApplication app(argc, argv);
    auto marker = reinterpret_cast<Marker>(dlsym(RTLD_DEFAULT,"br1_cost_stage"));
    auto dump = reinterpret_cast<Action>(dlsym(RTLD_DEFAULT,"br1_cost_dump"));
    auto reset = reinterpret_cast<Action>(dlsym(RTLD_DEFAULT,"br1_cost_reset"));
    auto netBegin = reinterpret_cast<Marker>(dlsym(RTLD_DEFAULT,"br1_net_begin"));
    auto netEnd = reinterpret_cast<Action>(dlsym(RTLD_DEFAULT,"br1_net_end"));
    auto netDrain = reinterpret_cast<Action>(dlsym(RTLD_DEFAULT,"br1_net_drain"));
    using ExecBegin=void *(*)(const char *,const char *,uintptr_t);
    using ExecEnd=void (*)(void *);
    auto execBegin=reinterpret_cast<ExecBegin>(dlsym(RTLD_DEFAULT,"br1_exec_begin"));
    auto execEnd=reinterpret_cast<ExecEnd>(dlsym(RTLD_DEFAULT,"br1_exec_end"));
    check(netBegin && netEnd && netDrain && execBegin && execEnd);
    QVector<int> cases{0,1,2,3,4,5,6,7};
    if (qEnvironmentVariableIntValue("BR1_REVERSE_CASES")) std::reverse(cases.begin(), cases.end());
    for (int id : cases) {
        const int pages = (id & 1) ? 16 : 1;
        const int writes = (id & 2) ? 16 : 1;
        const bool history = id & 4;
        const int width = pages == 16 ? 256 : 64;
        const int height = width;
        QByteArray initial(width * height * 4, char(0x19));
        QByteArray b(initial.size(), char(0x53)), c(initial.size(), char(0x6d));
        QByteArray output(initial.size(), 0);
        Stamp sums[7]{};
        const char *names[] = {"setup","write","read","finish","undo","redo","teardown"};
        uintptr_t operationIndex=0;
        auto measure = [&](int phase, auto &&operation) {
            auto event=execBegin("phase",names[phase],operationIndex++);
            if (marker) marker(phase == 0 ? 1 : phase == 4 ? 3 : phase == 5 ? 4 : phase == 6 ? 5 : 2);
            const auto a = now(); operation(); const auto z = now();
            sums[phase].wall += z.wall-a.wall; sums[phase].cpu += z.cpu-a.cpu; sums[phase].thread += z.thread-a.thread;
            if (marker) marker(0);
            execEnd(event);
        };
        netBegin(id);
        const auto wholeStart = now();
        for (int repeat = 0; repeat < 4; ++repeat) {
            std::unique_ptr<KisTiledDataManager> manager;
            KisMementoSP memento;
            const quint8 defaultPixel[4]{};
            measure(0,[&] {
                manager.reset(new KisTiledDataManager(4,defaultPixel));
                manager->writeBytes(reinterpret_cast<const quint8 *>(initial.constData()),0,0,width,height);
                manager->commit();
                if (history) memento = manager->getMemento();
            });
            const QByteArray *last = nullptr;
            for (int i=0; i<writes; ++i) {
                last = i % 2 ? &c : &b;
                measure(1,[&] { manager->writeBytes(reinterpret_cast<const quint8 *>(last->constData()),0,0,width,height); });
                measure(2,[&] { manager->readBytes(reinterpret_cast<quint8 *>(output.data()),0,0,width,height); });
                check(output == *last);
            }
            measure(3,[&] { manager->commit(); });
            if (history) {
                check(bool(memento));
                measure(4,[&] {
                    manager->rollback(memento);
                    manager->readBytes(reinterpret_cast<quint8 *>(output.data()),0,0,width,height);
                });
                check(output == initial);
                measure(5,[&] {
                    manager->rollforward(memento);
                    manager->readBytes(reinterpret_cast<quint8 *>(output.data()),0,0,width,height);
                });
                check(output == *last);
            }
            measure(6,[&] {
                if (history) { manager->purgeHistory(memento); memento.clear(); }
                manager.reset();
            });
        }
        const auto wholeEnd=now();
        const auto tailStart=now(); netDrain(); const auto tailEnd=now();
        netEnd();
        QJsonObject result{{"tail_cpu_ns",tailEnd.cpu-tailStart.cpu},{"tail_thread_cpu_ns",tailEnd.thread-tailStart.thread},
            {"tail_wall_ns",tailEnd.wall-tailStart.wall},{"case",id},{"pages",pages},{"writes",writes},{"history",history},{"lifetimes",4},
            {"bytes_per_write",initial.size()},{"semantic_ok",true},
            {"case_cpu_ns",wholeEnd.cpu-wholeStart.cpu},{"case_thread_cpu_ns",wholeEnd.thread-wholeStart.thread},{"case_wall_ns",wholeEnd.wall-wholeStart.wall}};
        for (int i=0;i<7;++i) result[names[i]]=QJsonObject{{"cpu_ns",sums[i].cpu},{"thread_cpu_ns",sums[i].thread},{"wall_ns",sums[i].wall}};
        std::fprintf(stderr,"BR1_STORAGE_JSON %s\n",QJsonDocument(result).toJson(QJsonDocument::Compact).constData());
        if (dump) dump();
        if (reset) reset();
    }
    std::fprintf(stderr,"BR1_STORAGE_COMPLETE 8\n");
    return 0;
}
