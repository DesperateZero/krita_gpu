"""Same-batch execution associations; no causal normalization or net prices."""
from collections import Counter, defaultdict, deque
import hashlib
import json
from pathlib import Path
import random
import re
import statistics as st

HERE=Path(__file__).resolve().parent;RUN=HERE/'execution-r2/observations'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=json.loads((RUN/'results.json').read_text());assert len(rows)==36 and all(r['passed'] for r in rows)
identity=json.loads((RUN/'identity-final.json').read_text());assert all(sha(p)==d for p,d in identity['hashes'].items())
events={};raw_hashes={}
for r in rows:
    dest=RUN/f"{r['index']:02}-{r['kind']}-{r['side']}-mode{r['mode']}"
    raw=(dest/'fixture.log').read_text();raw_hashes[str((dest/'fixture.log').relative_to(HERE))]=sha(dest/'fixture.log')
    for prefix,key in (('BR1_STORAGE_JSON','cases'),('BR1_NET_TOTAL','totals'),('BR1_NET_BUCKET','buckets')):
        assert [json.loads(x) for x in re.findall(prefix+r' (\{[^\n]+\})',raw)]==r[key]
    ev=[json.loads(x) for x in re.findall(r'BR1_EXEC_EVENT (\{[^\n]+\})',raw)]
    assert ev==json.loads((dest/'events.json').read_text());events[r['index']]=ev
rows=[r for r in rows if r['block']>=0]
assert Counter((r['block'],r['side'],r['mode']) for r in rows)=={(b,s,m):2 for b in range(4) for s in ('current','upstream') for m in (0,5)}
rng=random.Random(20261011);ranks=Counter()
for _ in range(100000):
    s=sorted(rng.randrange(4) for _ in range(4));ranks[s[1],s[2]]+=1
def quantile(v,p):
    v=sorted(v);x=(len(v)-1)*p;i=int(x);return v[i] if i==len(v)-1 else v[i]+(v[i+1]-v[i])*(x-i)
def estimate(v):
    vs=sorted(v);d=Counter()
    for (a,b),n in ranks.items():d[(vs[a]+vs[b])/2]+=n
    values=[]
    for value,n in sorted(d.items()):values.extend([value]*n)
    return dict(median=st.median(v),mean=st.mean(v),ci95=[quantile(values,.025),quantile(values,.975)],blocks=v)
def describe(v):
    return None if not v else dict(n=len(v),min=min(v),median=st.median(v),mean=st.mean(v),p95=quantile(v,.95),max=max(v),sum=sum(v))
def blocks(side,mode,f):return [st.mean(f(r) for r in rows if (r['block'],r['side'],r['mode'])==(b,side,mode)) for b in range(4)]
def diff(a,b):return [x-y for x,y in zip(a,b)]
def total(r,c):return next(t for t in r['totals'] if t['case']==c)
def case(r,c):return next(t for t in r['cases'] if t['case']==c)
def counts(r,c,role=None):
    v=Counter()
    for b in r['buckets']:
        if b['case']==c and (role is None or b['role']==role):v[b['name']]+=b['count']
    return v
def shortname(name):
    for a,b in [('KisPageHistoryCollector','history'),('KisPageRetirementQueue','retirement'),('KisImageEpochTreeStorage','epoch_storage'),('KisPageStore9configure','owner_close'),('PreparedPublication','metadata_prepared_cleanup')]:
        if a in name:return b
    return name

answer={}
for c in range(8):
    disturbance={}
    for side in ('current','upstream'):
        disturbance[side]={}
        for name,key in [('process','process_ns'),('foreground','foreground_ns'),('reclaimer',None)]:
            f=(lambda r:total(r,c)['roles_ns'][1]/1e6) if key is None else (lambda r,key=key:total(r,c)[key]/1e6)
            disturbance[side][name]=estimate(diff(blocks(side,5,f),blocks(side,0,f)))
    qualified=all(-.75<=disturbance[s][n]['ci95'][0] and disturbance[s][n]['ci95'][1]<=.75 for s in disturbance for n in ('process','foreground'))
    on=[r for r in rows if r['mode']==5];current=[r for r in on if r['side']=='current']
    count_ranges={}
    keys=set().union(*(counts(r,c) for r in current))|{'history_restarts','history_rescans','history_retry_wakeups','history_retry_armed','history_blocked_pass','retirement_retry_wakeups','retirement_retry_armed'}
    for k in sorted(keys):count_ranges[k]=[min(counts(r,c)[k] for r in current),max(counts(r,c)[k] for r in current)]
    records=[];phase_groups=defaultdict(list);job_groups=defaultdict(list)
    for r in on:
        es=[e for e in events[r['index']] if e['case']==c]
        phases=[e for e in es if e['kind']=='phase'];jobs=[e for e in es if e['kind']=='job']
        queue=deque();waiting=[]
        for e in sorted((e for e in es if e['kind'] in ('enqueue','dequeue')),key=lambda e:e['start'][0]):
            if e['kind']=='enqueue':queue.append(e)
            else:
                a=queue.popleft();assert (a['key'],a['name'])==(e['key'],e['name'])
                # Split enqueue→dequeue into overlap with prior jobs and uncovered elapsed.
                lo,hi=a['start'][0],e['start'][0]
                covered=sum(max(0,min(hi,j['end'][0])-max(lo,j['start'][0])) for j in jobs)
                assert 0<=covered<=hi-lo
                waiting.append(dict(name=shortname(e['name']),elapsed_ns=hi-lo,prior_job_overlap_ns=covered,uncovered_ns=hi-lo-covered))
        assert not queue
        job_summary={}
        for name in sorted({shortname(e['name']) for e in jobs}):
            js=[e for e in jobs if shortname(e['name'])==name]
            job_summary[name]=dict(count=len(js),cpu_ms=sum(e['end'][1]-e['start'][1] for e in js)/1e6,
                wall_ms=sum(e['end'][0]-e['start'][0] for e in js)/1e6,work=dict(sum((Counter(e['counts']) for e in js),Counter())))
            for e in js:job_groups[(r['side'],name)].append((r['index'],e))
        locks={}
        for group in ('history_owner','retirement_queue'):
            for role in (0,1,2):
                ls=[e for e in es if e['kind']=='lock' and e['role']==role and e['name'].startswith(group)]
                if ls:locks[group+':role'+str(role)]={k:describe([(e['end'][p]-e['start'][p])/1e3 for e in ls]) for k,p in [('elapsed_us',0),('thread_cpu_us',1)]}
        phase_summary={}
        for name in sorted({e['name'] for e in phases}):
            ps=[e for e in phases if e['name']==name]
            phase_summary[name]=dict(count=len(ps),cpu_ms=sum(e['end'][1]-e['start'][1] for e in ps)/1e6,
                endpoint_cpus=dict(Counter(str((e['start'][2],e['end'][2])) for e in ps)),
                endpoint_qos=dict(Counter(str((e['start'][3],e['end'][3])) for e in ps)),
                work=dict(sum((Counter(e['counts']) for e in ps),Counter())))
            for e in ps:phase_groups[(r['side'],name)].append((r['index'],e))
        records.append(dict(index=r['index'],side=r['side'],process_ms=total(r,c)['process_ns']/1e6,foreground_ms=total(r,c)['foreground_ns']/1e6,
            total_counts=dict(counts(r,c)),role_counts={str(role):dict(counts(r,c,role)) for role in range(5)},phases=phase_summary,jobs=job_summary,
            queue={k:describe([w[k]/1e3 for w in waiting]) for k in ('elapsed_ns','prior_job_overlap_ns','uncovered_ns')},locks=locks,
            job_cpu_endpoints=dict(Counter(str((j['start'][2],j['end'][2])) for j in jobs)),
            job_qos_endpoints=dict(Counter(str((j['start'][3],j['end'][3])) for j in jobs))))
    slow=[]
    for side in ('current','upstream'):
        rr=[v for v in records if v['side']==side]
        for name in sorted(set().union(*(v['phases'].keys() for v in rr))):
            med=st.median(v['phases'][name]['cpu_ms']/v['phases'][name]['count'] for v in rr)
            for v in rr:
                value=v['phases'][name]['cpu_ms']/v['phases'][name]['count']
                if value>1.5*med:slow.append(dict(index=v['index'],side=side,phase=name,ratio=value/med,phase=v['phases'][name]))
    def comparisons(groups):
        result=[]
        for (side,name),values in sorted(groups.items()):
            sigs=defaultdict(lambda:defaultdict(list))
            for index,e in values:
                signature=tuple(sorted(e['counts'].items()))
                endpoint=(e['start'][2],e['end'][2],e['start'][3],e['end'][3])
                sigs[signature][endpoint].append((index,(e['end'][1]-e['start'][1])/1e3))
            for signature,groups2 in sigs.items():
                eligible={k:v for k,v in groups2.items() if len(v)>=20 and len({i for i,t in v})>=3}
                if len(eligible)<2:continue
                result.append(dict(side=side,name=name,work=dict(signature),groups=[dict(endpoint=k,operations=len(v),processes=sorted({i for i,t in v}),
                    process_mean_cpu_us={str(i):st.mean(t for j,t in v if j==i) for i in sorted({i for i,t in v})}) for k,v in sorted(eligible.items())]))
        return result
    answer[str(c)]=dict(joint_observer_qualified=qualified,disturbance_ms=disturbance,count_ranges=count_ranges,records=records,
        slow_phases=slow,phase_same_work_cpu_associations=comparisons(phase_groups),job_same_work_cpu_associations=comparisons(job_groups),
        off_extra_process_ms=estimate(diff(blocks('current',0,lambda r:total(r,c)['process_ns']/1e6),blocks('upstream',0,lambda r:total(r,c)['process_ns']/1e6))))

result=dict(protocol='EXECUTION_PROTOCOL.md',processes=36,diagnostic_processes=32,capability_processes=4,
    statistics='4 independent blocks; 100000 bootstrap seed20261011; pointwise95%; event distributions descriptive only',
    raw_hashes=raw_hashes,cases=answer,selected_design=None,legal_net_recoverable_ms=None,
    limitations=['CPU endpoint queries do not measure residency or frequency','QoS value is a query, not a scheduling guarantee',
        'queue uncovered elapsed is not runnable time','lock acquire interval is not kernel blocked time',
        'failed disturbance disallows raw product mechanism prices','mode0 slow processes have no internal counts or CPU queries'])
(HERE/'execution-summary.json').write_text(json.dumps(result,indent=2)+'\n')
for c in ('3','7'):
    x=answer[c]
    print(json.dumps(dict(case=c,qualified=x['joint_observer_qualified'],disturbance=x['disturbance_ms']['current'],
        off_extra=x['off_extra_process_ms'],slow=[{k:v for k,v in s.items() if k!='phase'} for s in x['slow_phases']],
        work={k:v for k,v in x['count_ranges'].items() if k.startswith(('history_','retirement_'))}),indent=2))
