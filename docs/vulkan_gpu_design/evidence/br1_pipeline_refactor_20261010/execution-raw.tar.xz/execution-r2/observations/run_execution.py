"""Fixed 36-process execution capability, with raw event/FIFO validation."""
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3];PRODUCT=ROOT/'krita'
DERIVED=HERE/'execution-r2';OUT=DERIVED/'observations'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def validate_events(events,side,mode):
    assert mode==5 or not events
    if mode!=5:return {}
    checks=collections.Counter()
    for case in range(8):
        es=[e for e in events if e['case']==case]
        for role in range(5):
            rs=[e for e in es if e['role']==role]
            assert [e['id'] for e in rs]==list(range(len(rs)))
        for e in es:
            assert e['end'][0]>=e['start'][0] and e['end'][1]>=e['start'][1]
            assert all(v>=0 for v in e['counts'].values())
        phases=[e for e in es if e['kind']=='phase'];writes=16 if case&2 else 1
        names=['setup']+['write','read']*writes+['finish']+(['undo','redo'] if case&4 else [])+['teardown']
        assert [p['name'] for p in phases]==names*4
        assert [p['key'] for p in phases]==list(range(len(phases)))
        assert all(p['role']==0 for p in phases)
        for a,b in zip(phases,phases[1:]):assert a['end'][0]<=b['start'][0]
        q=collections.deque();pairs=[]
        for e in sorted((e for e in es if e['kind'] in ('enqueue','dequeue')),key=lambda e:e['start'][0]):
            if e['kind']=='enqueue':q.append(e)
            else:
                a=q.popleft();assert (a['key'],a['name'])==(e['key'],e['name'])
                pairs.append((a,e))
        assert not q
        jobs=sorted((e for e in es if e['kind']=='job'),key=lambda e:e['start'][0])
        assert len(jobs)==len(pairs)
        for (a,d),j in zip(pairs,jobs):
            assert (a['key'],a['name'])==(j['key'],j['name']) and d['role']==j['role']==1
            assert a['start'][0]<=d['start'][0]<=j['start'][0]
        for a,b in zip(jobs,jobs[1:]):assert a['end'][0]<=b['start'][0]
        if side=='upstream':assert len(es)==len(phases)
        checks['cases']+=1;checks['phases']+=len(phases);checks['jobs']+=len(jobs)
        checks['lock_acquisitions']+=sum(e['kind']=='lock' for e in es)
    return dict(checks)

def main():
    identity=json.loads((DERIVED/'identity.json').read_text());hashes=identity['hashes']
    assert all(sha(p)==d for p,d in hashes.items())
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=PRODUCT,text=True).strip()==identity['head']
    assert not subprocess.check_output(['git','diff','--binary','HEAD'],cwd=PRODUCT)
    OUT.mkdir()
    for name in ('run_execution.py','EXECUTION_PROTOCOL.md'):(OUT/name).write_bytes((HERE/name).read_bytes())
    variants=[('current',0),('upstream',0),('current',5),('upstream',5)]
    sequence=[('capability',-1,s,m) for s,m in variants]
    for b in range(4):
        order=variants[b%4:]+variants[:b%4]
        sequence += [('diagnostic',b,s,m) for s,m in (*order,*reversed(order))]
    records=[]
    for index,(kind,block,side,mode) in enumerate(sequence):
        dest=OUT/f'{index:02}-{kind}-{side}-mode{mode}';dest.mkdir()
        build=PRODUCT/'_build-br0-cpu' if side=='current' else ROOT/'build/br1-cp0-20261003/upstream-build'
        env={k:v for k,v in os.environ.items() if not k.startswith(('DYLD_','BR1_','KIS_BR1_'))}
        settings=dict(QT_QPA_PLATFORM='offscreen',KIS_BR1_SEED='12345',KIS_BR1_PROFILE='0',KIS_BR1_STAGE_PROFILE='0',
            BR1_COST_MODE=str(mode),KIS_TEST_PREFIX_PATH=str(PRODUCT/'_install'),KIS_TEST_PLUGIN_PATH=str(build/'bin'),
            BR1_REVERSE_CASES=str(int(block>=0 and block%2)))
        env.update(settings);libdir=DERIVED/side;binary=libdir/'storage'
        command=['arch','-arm64','/usr/bin/env','DYLD_LIBRARY_PATH='+str(libdir)+':'+str(build/'bin'),'DYLD_PRINT_LIBRARIES=1',str(binary)]
        start=time.monotonic()
        with (dest/'fixture.log').open('x') as log:
            p=subprocess.Popen(command,cwd=build,env=env,stdout=log,stderr=subprocess.STDOUT)
            (OUT/'running.json').write_text(json.dumps(dict(index=index,pid=p.pid,side=side,mode=mode))+'\n')
            try:code,timeout=p.wait(timeout=120),False
            except subprocess.TimeoutExpired:p.kill();code,timeout=p.wait(timeout=10),True
        raw=(dest/'fixture.log').read_text();parse=lambda n:[json.loads(x) for x in re.findall(n+r' (\{[^\n]+\})',raw)]
        cases,totals,buckets,events=[parse(n) for n in ('BR1_STORAGE_JSON','BR1_NET_TOTAL','BR1_NET_BUCKET','BR1_EXEC_EVENT')]
        loaded={str(Path(p).resolve()):sha(Path(p).resolve()) for p in re.findall(r'^dyld\[\d+\]: <[^>]+> (.+)$',raw,re.M)
            if Path(p).is_file() and str(Path(p).resolve()).startswith(str(ROOT))}
        lib=libdir/'libkritaimage.21.0.0.dylib'
        loading_ok=str(lib) in loaded and sum(Path(p).name==lib.name for p in loaded)==1
        reference=json.loads(next((HERE/'net-ledger-r1/observations').glob('*-capability-'+side+'-mode0/runtime.json')).read_text())
        ignore={'storage',lib.name}
        dependencies_ok={Path(p).name:d for p,d in reference.items() if Path(p).name not in ignore}=={
            Path(p).name:d for p,d in loaded.items() if Path(p).name not in ignore}
        for p,d in loaded.items():assert hashes.get(p,d)==d,p;hashes[p]=d
        expected=list(reversed(range(8))) if block>=0 and block%2 else list(range(8))
        semantic_ok=[c['case'] for c in cases]==expected and 'BR1_STORAGE_COMPLETE 8' in raw and all(
            c['semantic_ok'] and c['lifetimes']==4 and c['pages']==(16 if c['case']&1 else 1) and
            c['writes']==(16 if c['case']&2 else 1) and c['history']==bool(c['case']&4) for c in cases)
        errors=[];checks={}
        if [c['case'] for c in totals]!=expected or any(c['errors'] or c['mode']!=mode for c in totals):errors.append('boundary')
        if mode==0 and (buckets or events):errors.append('off has data')
        if any(b['cpu_ns'] or b['self_ns'] for b in buckets):errors.append('hot scope clock')
        try:checks=validate_events(events,side,mode)
        except Exception as e:errors.append('event validation: '+repr(e))
        passed=code==0 and not timeout and loading_ok and dependencies_ok and semantic_ok and not errors
        row=dict(index=index,kind=kind,block=block,side=side,mode=mode,command=command,settings=settings,exit=code,
            timed_out=timeout,reaped=True,seconds=time.monotonic()-start,loading_ok=loading_ok,dependencies_ok=dependencies_ok,
            semantic_ok=semantic_ok,errors=errors,passed=passed,cases=cases,totals=totals,buckets=buckets,event_checks=checks)
        (dest/'events.json').write_text(json.dumps(events,separators=(',',':'))+'\n')
        (dest/'result.json').write_text(json.dumps(row,indent=2)+'\n');(dest/'runtime.json').write_text(json.dumps(loaded,indent=2)+'\n')
        records.append(row);(OUT/'results.json').write_text(json.dumps(records,indent=2)+'\n')
        print(json.dumps(dict(index=index,side=side,mode=mode,passed=passed,checks=checks,errors=errors)),flush=True)
        assert passed,dest
    assert all(sha(p)==d for p,d in hashes.items())
    assert not subprocess.check_output(['git','diff','--binary','HEAD'],cwd=PRODUCT)
    (OUT/'identity-final.json').write_text(json.dumps(dict(verified=True,hashes=hashes),indent=2)+'\n')
    (OUT/'running.json').write_text(json.dumps(dict(state='complete',processes=len(records)))+'\n')
    print(f'{len(records)} processes complete.',flush=True)

if __name__=='__main__':main()
