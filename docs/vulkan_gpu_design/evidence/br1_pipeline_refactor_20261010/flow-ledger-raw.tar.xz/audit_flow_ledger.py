"""Reconcile one frozen time batch and the complete observed lifetime counts."""
from collections import Counter
import ast
import hashlib
import io
import json
from pathlib import Path
import re
import statistics as st
import subprocess
import tarfile

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3];PRODUCT=ROOT/'krita'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=PRODUCT,text=True).strip()=='11c6895ddfeae074df727c76dcbf9e12988479ee'
assert not subprocess.check_output(['git','diff','--binary','HEAD'],cwd=PRODUCT)
library=PRODUCT/'_build-br0-cpu/bin/libkritaimage.21.0.0.dylib'
assert sha(library)=='91e962c2c43379697b13f37a2ee388d408440c67f3e21458e75c70dab4b21b38'
inputs={}
def read(rel):
    p=HERE/rel;inputs[rel]=sha(p);return json.loads(p.read_text())
original=read('net-ledger-r1/observations/results.json')
assert len(original)==68 and all(r['passed'] for r in original)
off=[r for r in original if r['kind']=='timing' and r['mode']==0]
assert len(off)==32 and Counter((r['side'],r['block']) for r in off)=={(s,b):2 for s in ('current','upstream') for b in range(8)}
old_raw_files=[]
for row in off:
    run=HERE/'net-ledger-r1/observations'/f"{row['index']:02}-timing-{row['side']}-mode0"
    raw=(run/'fixture.log').read_text()
    for prefix,key in (('BR1_STORAGE_JSON','cases'),('BR1_NET_TOTAL','totals'),('BR1_NET_BUCKET','buckets')):
        parsed=[json.loads(x) for x in re.findall(prefix+r' (\{[^\n]+\})',raw)]
        assert parsed==row[key],(run,key)
    assert row['reaped'] and not row['timed_out'] and row['semantic_ok'] and not row['errors']
    assert all(x['semantic_ok'] and x['lifetimes']==4 for x in row['cases'])
    assert json.loads((run/'result.json').read_text())==row
    for name in ('fixture.log','result.json','runtime.json'):
        p=run/name;inputs[str(p.relative_to(HERE))]=sha(p);old_raw_files.append(p)
summary=read('net-ledger-summary.json');cases={}
old_identity=read('net-ledger-r1/observations/identity-final.json');assert old_identity['verified']
old_checks=0;frozen_resolutions={}
for name,digest in old_identity['hashes'].items():
    p=Path(name)
    if not p.exists() or sha(p)!=digest:
        # Later diagnostics updated these living entry files. Verify the exact
        # original bytes, never substitute the current protocol or skip them.
        assert p.name in ('NET_PROTOCOL.md','run_net_ledger.py'),name
        frozen=HERE/'net-ledger-r1/observations'/p.name
        assert sha(frozen)==digest,name
        frozen_resolutions[name]=str(frozen)
    else:assert sha(p)==digest
    old_checks+=1
stages=('setup','write','read','finish','undo','redo','teardown')
max_error=0
for c in range(8):
    values={s:[] for s in ('current','upstream')}
    for side in values:
        for block in range(8):
            parts=[]
            for r in off:
                if (r['side'],r['block'])!=(side,block):continue
                x=next(x for x in r['cases'] if x['case']==c);t=next(x for x in r['totals'] if x['case']==c)
                d={s:x[s]['thread_cpu_ns']/1e6 for s in stages}
                d['case_frame']=(x['case_thread_cpu_ns']-sum(x[s]['thread_cpu_ns'] for s in stages))/1e6
                d['tail_foreground']=x['tail_thread_cpu_ns']/1e6
                d['observer_boundary_foreground']=(t['foreground_ns']-x['case_thread_cpu_ns']-x['tail_thread_cpu_ns'])/1e6
                for role,name in enumerate(('unused','reclaimer','monitor','pooler','swapper')):
                    if role:d[name]=t['roles_ns'][role]/1e6
                d['unregistered_boundary']=(t['process_ns']-t['foreground_ns']-sum(t['roles_ns'][1:]))/1e6
                error=abs(sum(d.values())-t['process_ns']/1e6);max_error=max(max_error,error);assert error<1e-9
                parts.append(d)
            values[side].append({k:st.mean(x[k] for x in parts) for k in parts[0]})
    extra={k:[values['current'][b][k]-values['upstream'][b][k] for b in range(8)] for k in values['current'][0]}
    total=[sum(v[b] for v in extra.values()) for b in range(8)]
    known=summary['cases'][str(c)]['off_current_extra_ms']['process']
    assert all(abs(a-b)<1e-9 for a,b in zip(total,known['blocks']))
    cases[str(c)]=dict(pages=16 if c&1 else 1,writes=16 if c&2 else 1,history=bool(c&4),
        components_extra_mean_ms={k:st.mean(v) for k,v in extra.items()},components_extra_blocks_ms=extra,
        foreground_extra_ms=summary['cases'][str(c)]['off_current_extra_ms']['foreground'],
        process_extra_ms=known,source='net-ledger-r1/observations/results.json mode0 only')
census=read('flow-census-r1/results.json');assert len(census)==4 and all(r['passed'] and r['reaped'] and not r['timed_out'] for r in census)
for row in census:
    run=HERE/'flow-census-r1/runs'/f"{row['index']:02}-{row['side']}"
    raw=(run/'fixture.log').read_text()
    for prefix,key in (('BR1_STORAGE_JSON','cases'),('BR1_NET_TOTAL','totals'),('BR1_NET_BUCKET','buckets')):
        parsed=[json.loads(x) for x in re.findall(prefix+r' (\{[^\n]+\})',raw)]
        assert parsed==row[key],(run,key)
    inputs[str((run/'fixture.log').relative_to(HERE))]=sha(run/'fixture.log')
    assert all(x['semantic_ok'] and x['lifetimes']==4 for x in row['cases'])
census_identity=read('flow-census-r1/identity-final.json');assert census_identity['verified']
checks=0
for p,d in census_identity['hashes'].items():assert sha(p)==d,p;checks+=1
counts={}
for c in range(8):
    out={s:[] for s in ('current','upstream')}
    roles={s:[] for s in out}
    for r in census:
        n=Counter();split={}
        for b in r['buckets']:
            assert b['cpu_ns']==b['self_ns']==0
            if b['case']!=c:continue
            n[b['name']]+=b['count'];split.setdefault(str(b['role']),{})[b['name']]=b['count']
        out[r['side']].append(dict(n));roles[r['side']].append(split)
    assert all(v[0]==v[1] for v in out.values())
    current=Counter(out['current'][0]);upstream=Counter(out['upstream'][0]);k=16 if c&1 else 1;w=16 if c&2 else 1;f=4*k*(w+1)
    equal=('fresh_accepted','rows','binding_created','binding_destroyed','provider_adopted','provider_allocation_removed',
        'provider_physical_registered','provider_physical_released','provider_retire','owner_backing_installed',
        'owner_backing_removed','owner_physical_installed','owner_physical_removed','proof_installed','proof_revoked')
    assert all(current[n]==f for n in equal)
    assert current['free']==f+4 and upstream['free']==8*k+4
    assert current['pending_ticket_issued']==f+8
    assert all(current[n]==0 for n in ('provider_final_allocations','owner_final_backings','owner_final_proofs'))
    assert current['metadata_default_created']+current['metadata_version_created']==current['metadata_default_removed']+current['metadata_version_removed']+current['metadata_final_versions']
    assert current['descriptor_prepared']==current['descriptor_installed']+current['descriptor_discarded']
    assert current['descriptor_installed']==current['descriptor_removed']+current['descriptor_final_nodes']
    assert all(current[n]==4 for n in ('owner_destroy','provider_destroy','publication_destroy','metadata_destroy'))
    counts[str(c)]=dict(counts={s:v[0] for s,v in out.items()},role_observations=roles,
        identical_totals_in_two_runs=True,physical_extra=f-8*k,terminal_balances_verified=True)
plan=HERE.parent/'br1_pagestore_equivalent_pipeline_20261010/PIPELINE_PLAN.md'
inputs['../br1_pagestore_equivalent_pipeline_20261010/PIPELINE_PLAN.md']=sha(plan)
section=plan.read_text().split('### 13. 扩大后的修改索引与删除追踪',1)[1].split('### 14.',1)[0]
rows=[l for l in section.splitlines() if re.match(r'^\| T\d\d\.\d+ ',l)]
ids=[l.split(' ')[1] for l in rows];assert len(ids)==len(set(ids))==33 and all(len(l.split('|'))==8 for l in rows)
flow_map={
    'input_operation':['T01.1','T01.2','T02.1','T02.2'],
    'read_selection':['T06.1'],
    'target_physical':['T03.1','T03.2','T03.3','T05.1','T05.2'],
    'logical_identity':['T03.1','T04.1'],
    'accept_publish':['T02.3','T02.4','T04.2','T04.3','T04.4','T04.5','T04.6'],
    'adapter_delivery':['T01.3','T01.4','T04.7','T06.3'],
    'read_terminal':['T06.1','T07.2'],
    'history_restore':['T04.8','T04.9','T04.10'],
    'enumerate_clone_import':['T04.11','T04.12','T06.2'],
    'collection_retirement':['T07.2'],
    'cancel_close':['T02.2','T07.1','T07.3'],
    'evidence_controls':['T08.1','T08.2'],
}
assert set(ids)==set(x for v in flow_map.values() for x in v)
for f in ('cost-ledger-storage-work-summary.json','net-background-summary.json','detach-summary.json','completion-summary.json','payload-counts-summary.json'):
    read(f)
result=dict(product='11c6895ddfeae074df727c76dcbf9e12988479ee',product_changed=False,
    library_sha256=sha(library),input_hashes=inputs,old_off_processes_reconciled=32,new_count_processes=4,
    identity_checks=checks,old_identity_checks=old_checks,frozen_identity_resolutions=frozen_resolutions,
    maximum_process_closure_error_ms=max_error,cases=cases,census=counts,flow_map=flow_map,
    matrix_rows=33,matrix_columns=6,full_pipeline_data_complete=False,selected_optimal_design=None,
    new_optimization_implementation_authorized_by_this_audit=False,
    missing=['H1 qualified exclusive mechanism increment','Lock/ready/dispatch causal waits',
        'Peak live/reserved bytes by real lifetime and pressure state','All production operation families performance coverage',
        'Comparable lawful full-design counterfactuals and joint controls'],
    limits=['Same-batch arithmetic closure is not mechanism attribution.',
        'Counters are baseline observations, no new time or net-price qualification.',
        'Metadata/descriptor terminal records are counted separately from payload ownership.',
        'No cross-batch subtraction, no conversion of counts to milliseconds or percentages of recoverable time.'])
(HERE/'flow-ledger-audit.json').write_text(json.dumps(result,indent=2)+'\n')
for c in ('3','7'):print(c,cases[c]['components_extra_mean_ms'])
print('new count processes',len(census),'identity checks',checks,'covered original rows',len(ids),'closure max',max_error)
print('old identity checks',old_checks,'exact frozen entry resolutions',len(frozen_resolutions))

# Retain text evidence, including the pre-build rejection. Linked binaries and
# dependency objects are intentionally represented by verified identities.
paths=[HERE/n for n in ('FLOW_AUDIT_PROTOCOL.md','flow_census.py','audit_flow_ledger.py','flow-ledger-audit.json')]+old_raw_files
suffixes={'.md','.py','.json','.log','.cpp','.h','.diff'}
for root in ('flow-census-r0','flow-census-r1'):
    paths.extend(p for p in (HERE/root).rglob('*') if p.is_file() and not p.is_symlink() and p.suffix in suffixes)
for name in ('results.json','identity-final.json','NET_PROTOCOL.md','run_net_ledger.py'):
    paths.append(HERE/'net-ledger-r1/observations'/name)
paths.extend(HERE/n for n in ('net-ledger-summary.json','net_observer.h','net_observer.cpp'))
for name in ('net_observer.h','net_observer.cpp'):
    paths.append(HERE/'net-ledger-r3'/name)
members={};archive=HERE/'flow-ledger-raw.tar.xz'
with tarfile.open(archive,'w:xz') as tar:
    for p in sorted(set(paths)):
        data=p.read_bytes();name=str(p.relative_to(HERE))
        if p.suffix=='.py':ast.parse(data,filename=name)
        item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0
        tar.addfile(item,io.BytesIO(data));members[name]=dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(archive) as tar:
    assert {x.name for x in tar.getmembers()}==set(members)
    for item in tar.getmembers():assert hashlib.sha256(tar.extractfile(item).read()).hexdigest()==members[item.name]['sha256']
manifest=dict(archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,members=members,
    omitted='Compiled libraries, objects and executables are recorded by identity, not packaged.',
    old_batch='Original 68-process results retained; only 32 mode0 processes enter the time ledger, and their raw logs/commands/runtime hashes are included. Full original batch also remains in net-ledger-raw.tar.xz.')
(HERE/'flow-ledger-raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('archive',len(members),'members',archive.stat().st_size,'bytes',sha(archive))
