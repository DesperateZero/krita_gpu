"""Baseline-only flow census. Derivatives, never product edits or unit prices."""
import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3];PRODUCT=ROOT/'krita';BUILD=PRODUCT/'_build-br0-cpu'
OUT=HERE/'flow-census-r1';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
parser=argparse.ArgumentParser();parser.add_argument('phase',choices=('build','run'));args=parser.parse_args()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=PRODUCT,text=True).strip()=='11c6895ddfeae074df727c76dcbf9e12988479ee'
assert not subprocess.check_output(['git','diff','--binary','HEAD'],cwd=PRODUCT)

if args.phase=='build':
    OUT.mkdir();hashes={}
    for name in ('flow_census.py','FLOW_AUDIT_PROTOCOL.md'):(OUT/name).write_bytes((HERE/name).read_bytes())
    rows=json.loads((BUILD/'compile_commands.json').read_text())
    link=next(x for x in json.loads((HERE/'net-ledger-r3/current/commands.json').read_text()) if '-dynamiclib' in x)
    index=[];commands=[]
    def replace(text,old,new):
        assert text.count(old)==1,old
        return text.replace(old,new)
    def change(text,old,name):
        index.append(dict(anchor=old,counter=name))
        return replace(text,old,old+'\n        br1_net_count("'+name+'");')
    dest=OUT/'current';dest.mkdir()
    header=PRODUCT/'libs/image/pagestore/KisPagePublicationCoordinator_p.h'
    original=header.read_text();hashes[str(header)]=sha(header)
    derived=replace(original,'    ~KisPagePublicationCoordinator() = default;',
        '''    ~KisPagePublicationCoordinator() {
        br1_net_count("publication_destroy");
        for (const auto &entry : m_descriptors) {
            (void)entry; br1_net_count("descriptor_final_nodes");
        }
    }''')
    (dest/header.name).write_text('#include "net_observer.h"\n'+derived)
    (dest/(header.name+'.diff')).write_text(''.join(difflib.unified_diff(original.splitlines(True),derived.splitlines(True))))
    sources=['KisTiles3PageReplicaProvider.cpp','KisPageOwnerLedger.cpp','KisPageMetadataCoordinator.cpp',
             'KisPagePublicationCoordinator.cpp','KisCompletionRegistry.cpp','KisPageStore.cpp']
    for name in sources:
        source=PRODUCT/'libs/image/pagestore'/name;original=source.read_text();text=original;hashes[str(source)]=sha(source)
        if name=='KisTiles3PageReplicaProvider.cpp':
            text=change(text,'            residencyObserver->storageAllocator(), prepared.handle, &handoffAdmission);','binding_created')
            text=replace(text,'    ~Tiles3ResidentBinding() override { if (m_tile) m_tile->deref(); }',
                '    ~Tiles3ResidentBinding() override { br1_net_count("binding_destroyed"); if (m_tile) m_tile->deref(); }')
            text=change(text,'        if (!accepted.inserted) return false;','provider_adopted')
            text=change(text,'        committedBytes += bytes;','provider_physical_registered')
            text=change(text,'            committedBytes -= bytes;','provider_physical_released')
            text=change(text,'        released = d->allocations.extract(retirement.allocation);','provider_allocation_removed')
            text=change(text,'    KisTileData *retired = nullptr;','provider_retire')
            text=replace(text,'    d->revokeBindings();','''    br1_net_count("provider_destroy");
    for (const auto &entry : d->allocations) { (void)entry; br1_net_count("provider_final_allocations"); }
    d->revokeBindings();''')
        elif name=='KisPageOwnerLedger.cpp':
            text=change(text,'    Q_ASSERT(installedBacking.inserted);','owner_backing_installed')
            text=change(text,'        physical = installed.position;','owner_physical_installed')
            text=change(text,'    released = d->backings.extract(found);','owner_backing_removed')
            text=change(text,'        releasedPhysical = d->physicalBackings.extract(physical);','owner_physical_removed')
            text=change(text,'    d->sealedProofs.insert(*record);','proof_installed')
            text=change(text,'    d->sealedProofs.erase(proofIt);','proof_revoked')
            text=replace(text,'    d->domainAdmission->detach();','''    br1_net_count("owner_destroy");
    for (const auto &entry : d->backings) { (void)entry; br1_net_count("owner_final_backings"); }
    for (const auto &entry : d->sealedProofs) { (void)entry; br1_net_count("owner_final_proofs"); }
    d->domainAdmission->detach();''')
        elif name=='KisPageMetadataCoordinator.cpp':
            text=replace(text,'            indexPublication(page, record);\n        } else {',
                '''            indexPublication(page, record);
            br1_net_count(snapshot.version.isDefaultPixel() ? "metadata_default_created" : "metadata_version_created");
        } else {''')
            text=replace(text,'        const bool recordErased = arenas->versions.erase(slot);',
                '''        const bool censusDefault = identity.isDefaultPixel();
        const bool recordErased = arenas->versions.erase(slot);
        if (recordErased) br1_net_count(censusDefault ? "metadata_default_removed" : "metadata_version_removed");''')
            text=replace(text,'    Private::destroy(m_core.exchange(nullptr, std::memory_order_acq_rel));',
                '''    br1_net_count("metadata_destroy");
    const auto terminal = footprint();
    for (quint64 i=0; i<terminal.versions; ++i) br1_net_count("metadata_final_versions");
    for (quint64 i=0; i<terminal.replicas; ++i) br1_net_count("metadata_final_replicas");
    Private::destroy(m_core.exchange(nullptr, std::memory_order_acq_rel));''')
        elif name=='KisPagePublicationCoordinator.cpp':
            text=replace(text,'        nodes.emplace(changes[i].version, std::move(value));',
                '''        const auto censusInserted = nodes.emplace(changes[i].version, std::move(value)).second;
        if (censusInserted) br1_net_count("descriptor_prepared");''')
            text=change(text,'            m_descriptors.insert(prepared->extract(current));','descriptor_installed')
            text=replace(text,'    if (m_descriptors.erase(version) != 0)\n        ++m_descriptorRevision;',
                '''    if (m_descriptors.erase(version) != 0) {
        br1_net_count("descriptor_removed");
        ++m_descriptorRevision;
    }''')
            text=replace(text,'    *prepared = {};','''    for (const auto &entry : *prepared) { (void)entry; br1_net_count("descriptor_discarded"); }
    *prepared = {};''')
        elif name=='KisCompletionRegistry.cpp':
            text=change(text,'    ++sourceIt->second.nextValue;','pending_ticket_issued')
        elif name=='KisPageStore.cpp':
            # Preserve the already audited success count, including its exact acceptance point.
            text=(HERE/'net-ledger-r3/current'/name).read_text()
        text='#include "net_observer.h"\n'+text
        derived=dest/name;derived.write_text(text)
        derived.with_suffix('.cpp.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile=str(source),tofile=str(derived))))
        cmd=shlex.split(next(r['command'] for r in rows if r['file']==str(source)))
        old=next(t for t in link if t.endswith('/'+name+'.o'));obj=str(dest/(name+'.o'))
        cmd[cmd.index('-o')+1]=obj;cmd[cmd.index('-c')+1]=str(derived)
        cmd.insert(1,'-I'+str(dest));cmd+=['-I'+str(source.parent),'-I'+str(HERE/'net-ledger-r3')]
        link=[obj if t==old else t for t in link];commands.append(cmd)
    link[link.index('-o')+1]=str(dest/'libkritaimage.21.0.0.dylib');commands.append(link)
    for t in link:
        if t.endswith('.o') and not t.startswith(str(OUT)):
            p=Path(t) if Path(t).is_absolute() else BUILD/t;hashes[str(p)]=sha(p)
    (OUT/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    (OUT/'counter-anchors.json').write_text(json.dumps(index,indent=2)+'\n')
    for i,cmd in enumerate(commands):
        print('build',i,flush=True)
        with (OUT/f'build-{i}.log').open('x') as log:subprocess.run(cmd,cwd=BUILD,stdout=log,stderr=subprocess.STDOUT,check=True)
    (dest/'libkritaimage.21.dylib').symlink_to('libkritaimage.21.0.0.dylib')
    for p in OUT.rglob('*'):
        if p.is_file() and not p.is_symlink():hashes[str(p)]=sha(p)
    (OUT/'identity.json').write_text(json.dumps(dict(hashes=hashes),indent=2)+'\n')
else:
    dest=OUT/'runs';dest.mkdir();hashes=json.loads((OUT/'identity.json').read_text())['hashes']
    assert all(sha(p)==d for p,d in hashes.items())
    previous=json.loads((HERE/'net-ledger-r3/observations/results.json').read_text())
    records=[]
    for index,side in enumerate(('current','upstream','upstream','current')):
        reference=next(r for r in previous if r['side']==side)
        cmd=list(reference['command']);settings=dict(reference['settings']);settings['BR1_REVERSE_CASES']=str(index%2)
        if side=='current':cmd=[('DYLD_LIBRARY_PATH='+str(OUT/'current')+':'+str(BUILD/'bin')) if x.startswith('DYLD_LIBRARY_PATH=') else x for x in cmd]
        library=OUT/'current/libkritaimage.21.0.0.dylib' if side=='current' else HERE/'net-ledger-r3/upstream/libkritaimage.21.0.0.dylib'
        env={k:v for k,v in os.environ.items() if not k.startswith(('DYLD_','BR1_','KIS_BR1_'))};env.update(settings)
        run=dest/f'{index:02}-{side}';run.mkdir();(run/'command.json').write_text(json.dumps(dict(command=cmd,settings=settings),indent=2)+'\n')
        start=time.monotonic()
        with (run/'fixture.log').open('x') as log:
            process=subprocess.Popen(cmd,cwd=BUILD,env=env,stdout=log,stderr=subprocess.STDOUT)
            try:code,timeout=process.wait(timeout=120),False
            except subprocess.TimeoutExpired:process.kill();code,timeout=process.wait(timeout=10),True
        raw=(run/'fixture.log').read_text();parse=lambda n:[json.loads(x) for x in re.findall(n+r' (\{[^\n]+\})',raw)]
        cases,totals,buckets=[parse(n) for n in ('BR1_STORAGE_JSON','BR1_NET_TOTAL','BR1_NET_BUCKET')]
        expected=list(reversed(range(8))) if index%2 else list(range(8))
        loaded={str(Path(p).resolve()):sha(Path(p).resolve()) for p in re.findall(r'^dyld\[\d+\]: <[^>]+> (.+)$',raw,re.M)
                if Path(p).is_file() and str(Path(p).resolve()).startswith(str(ROOT))}
        loading_ok=str(library) in loaded and sum(Path(p).name==library.name for p in loaded)==1
        prior_paths=list((HERE/'net-ledger-r3/observations').glob('*'+side+'-mode3/runtime.json'))
        assert prior_paths
        prior=json.loads(prior_paths[0].read_text());ignore={'storage','libkritaimage.21.0.0.dylib'}
        deps_ok={Path(p).name:d for p,d in loaded.items() if Path(p).name not in ignore}=={Path(p).name:d for p,d in prior.items() if Path(p).name not in ignore}
        for p,d in loaded.items():assert hashes.get(p,d)==d,p;hashes[p]=d
        semantic_ok=[c['case'] for c in cases]==expected and all(c['semantic_ok'] and c['lifetimes']==4 for c in cases) and 'BR1_STORAGE_COMPLETE 8' in raw
        counts_ok=[t['case'] for t in totals]==expected and all(t['mode']==3 and not t['errors'] for t in totals) and not any(b['cpu_ns'] or b['self_ns'] for b in buckets)
        passed=code==0 and not timeout and loading_ok and deps_ok and semantic_ok and counts_ok
        row=dict(index=index,side=side,passed=passed,exit=code,timed_out=timeout,reaped=True,seconds=time.monotonic()-start,
                 loading_ok=loading_ok,dependencies_ok=deps_ok,semantic_ok=semantic_ok,counts_ok=counts_ok,cases=cases,totals=totals,buckets=buckets)
        (run/'runtime.json').write_text(json.dumps(loaded,indent=2)+'\n');(run/'result.json').write_text(json.dumps(row,indent=2)+'\n')
        records.append(row);(OUT/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(index,side,passed,flush=True)
        assert passed,run
    assert all(sha(p)==d for p,d in hashes.items())
    (OUT/'identity-final.json').write_text(json.dumps(dict(verified=True,hashes=hashes),indent=2)+'\n')
