# 机制净账判别：aggregate-r0（采样前冻结）

r0在第一个off capability的case0停止：tiles3 pooler按其零memory-limit正常退出，观察器随后读取失效Mach thread port而报错。没有计时样本。r1为具名线程增加进入/退出RAII，在原线程退出前读取CPU并保留累计值；边界查询与登记/退出使用独立诊断registry锁，热scope不使用该锁。其余实验不变，r0全部源/库/输出保留；r1重新领取原固定68过程，不把失败样本混入性能估计。

产品仍为11c6895ddfeae074df727c76dcbf9e12988479ee，上游9a24ae0d8c070884fb013594191002e1a1b39a19。只生成派生源、库和两侧ABI夹具，不修改产品或原对象。以原8个公共存储case、每case四manager寿命及所有像素/历史断言为共同工作；这不是业务Stroke或正式M6验收。

修复上轮两个证据缺口：使用固定TLS累计桶、仅thread CPU两端时钟，去掉逐事件日志、wall时钟及标签；对reclamation job连同dispose/finished计费，保留原任务动态类型。worker、monitor、tiles3 pooler/swapper另外用Mach线程CPU边界读数计费，未覆盖线程仍列残差，不将等待当CPU。机制inclusive与exclusive分开，只加后者。

保留原case端点，再单列显式kisDrainPageStoreReclamation的尾账；upstream无该队列，执行空hook。drain只证明即时任务排空，不代表未来deadline或全部物理债务关闭。每case测量窗口从begin hook完成准备后到drain完成；线程快照与process CPU端点不同时刻的读数偏移显式保留为残差。manager四寿命、结果核验及原stage不改变。原端点、增广端点和旧批不得混加。跨case活动scope、容量溢出、身份/语义/退出错误均停止；不删除失败。

四侧current-off/current-on/upstream-off/upstream-on各一次capability，然后8独立顺序块，每块四侧排列及其镜像各一次，总68过程；case顺序随块奇偶反转。每过程120s timeout、kill/reap。产品、原库、派生源/对象/库/命令、夹具及加载依赖前后核验。构建、采样、分析顺序执行。

统计每侧块内两过程均值，配对差的中位数及100000次seed20261011的pointwise95% bootstrap；加法账用同8块均值，不能加中位数。粗责任解释要求各侧K16/W16/H0、H1的完整前台on−off区间落在±0.75ms；process CPU另报告，不以总量抵消证明每个桶无扰动。线程归因只在边界有效、无活动尾且过程扰动可解释时使用。失败则报告未知，不扩样到通过。

三层分别裁决：当前责任成本；同义upstream差额；合法替代净预算。upstream没有同名细桶时，只能给映射范围/包络，不能把上游整条write重复扣到多个当前子桶。没有实现可构造替代、必要剩余工作和新增尾成本的项，其净预算仍未知。本批优先证伪“4.6ms都是未知管理成本/遗漏尾”“冷准备都是可删”“读侧只是memcpy”，不预授优化收益或960次删除。
