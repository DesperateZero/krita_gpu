"""Frozen 68-process diagnostic comparison, fail closed, no added samples."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import subprocess
import time

HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[3]; PRODUCT=ROOT/'krita'
DERIVED=HERE/'net-ledger-r1'; OUT=DERIVED/'observations'; OUT.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
identity=json.loads((DERIVED/'identity.json').read_text()); hashes=identity['hashes']
assert all(sha(p)==d for p,d in hashes.items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=PRODUCT,text=True).strip()==identity['head']
assert not subprocess.check_output(['git','diff','--binary','HEAD'],cwd=PRODUCT)
for p in (Path(__file__),HERE/'NET_PROTOCOL.md'):
    (OUT/p.name).write_bytes(p.read_bytes());hashes[str(p)]=sha(p)
(OUT/'identity-before.json').write_text(json.dumps(hashes,indent=2)+'\n')
variants=[('current',0),('upstream',0),('current',2),('upstream',2)]
sequence=[('capability',-1,s,m) for s,m in variants]
for b in range(8):
    order=variants[b%4:]+variants[:b%4]
    sequence += [('timing',b,s,m) for s,m in (*order,*reversed(order))]
records=[]
for index,(kind,block,side,mode) in enumerate(sequence):
    dest=OUT/f'{index:02}-{kind}-{side}-mode{mode}';dest.mkdir()
    build=PRODUCT/'_build-br0-cpu' if side=='current' else ROOT/'build/br1-cp0-20261003/upstream-build'
    env={k:v for k,v in os.environ.items() if not k.startswith(('DYLD_','BR1_','KIS_BR1_'))}
    settings=dict(QT_QPA_PLATFORM='offscreen',KIS_BR1_SEED='12345',KIS_BR1_PROFILE='0',KIS_BR1_STAGE_PROFILE='0',
        BR1_COST_MODE=str(mode),KIS_TEST_PREFIX_PATH=str(PRODUCT/'_install'),KIS_TEST_PLUGIN_PATH=str(build/'bin'),
        BR1_REVERSE_CASES=str(int(block>=0 and block%2)))
    env.update(settings)
    command=['arch','-arm64','/usr/bin/env','DYLD_LIBRARY_PATH='+str(DERIVED/side)+':'+str(build/'bin'),
        'DYLD_PRINT_LIBRARIES=1',str(DERIVED/side/'storage')]
    start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
    with (dest/'fixture.log').open('x') as log:
        p=subprocess.Popen(command,cwd=build,env=env,stdout=log,stderr=subprocess.STDOUT)
        (OUT/'running.json').write_text(json.dumps(dict(index=index,pid=p.pid,side=side,mode=mode))+'\n')
        try:code,timeout=p.wait(timeout=120),False
        except subprocess.TimeoutExpired:p.kill();code,timeout=p.wait(timeout=10),True
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    raw=(dest/'fixture.log').read_text()
    parse=lambda n:[json.loads(x) for x in re.findall(n+r' (\{[^\n]+\})',raw)]
    cases,totals,buckets=[parse(n) for n in ('BR1_STORAGE_JSON','BR1_NET_TOTAL','BR1_NET_BUCKET')]
    loaded={str(Path(p).resolve()):sha(Path(p).resolve()) for p in re.findall(r'^dyld\[\d+\]: <[^>]+> (.+)$',raw,re.M)
        if Path(p).is_file() and str(Path(p).resolve()).startswith(str(ROOT))}
    lib=DERIVED/side/'libkritaimage.21.0.0.dylib'
    loading_ok=str(lib) in loaded and sum(Path(p).name==lib.name for p in loaded)==1
    reference=json.loads(next((HERE/'cost-ledger-storage-r0').glob('*-capability-'+side+'/runtime.json')).read_text())
    ignore={'storage','probe',lib.name}
    dependencies_ok={Path(p).name:d for p,d in reference.items() if Path(p).name not in ignore}=={
        Path(p).name:d for p,d in loaded.items() if Path(p).name not in ignore}
    for p,d in loaded.items():assert hashes.get(p,d)==d,p;hashes[p]=d
    expected=list(reversed(range(8))) if block>=0 and block%2 else list(range(8))
    semantic_ok=[c['case'] for c in cases]==expected and 'BR1_STORAGE_COMPLETE 8' in raw and all(
        c['semantic_ok'] and c['lifetimes']==4 and c['pages']==(16 if c['case']&1 else 1) and
        c['writes']==(16 if c['case']&2 else 1) and c['history']==bool(c['case']&4) for c in cases)
    errors=[]
    if [c['case'] for c in totals]!=expected or any(c['errors'] or c['mode']!=mode for c in totals):errors.append('counter boundary')
    if (mode==0 and buckets) or (mode==2 and not buckets):errors.append('mode')
    if any(c['cpu_ns']<c['self_ns'] or not 0<=c['role']<5 for c in buckets):errors.append('bucket')
    if len({(v['case'],v['role'],v['name']) for v in buckets})!=len(buckets):errors.append('duplicate bucket')
    if mode==2 and side=='current':
        for c in (3,7):
            cs={b['name']:b for b in buckets if b['case']==c and b['role']==0}
            if cs.get('cold',{}).get('count')!=1088:errors.append('cold count')
            if cs.get('commit',{}).get('count')!=(68 if c==3 else 8):errors.append('commit count')
    passed=code==0 and not timeout and loading_ok and dependencies_ok and semantic_ok and not errors
    row=dict(index=index,kind=kind,block=block,side=side,mode=mode,command=command,settings=settings,exit=code,
        timed_out=timeout,reaped=True,seconds=time.monotonic()-start,loading_ok=loading_ok,dependencies_ok=dependencies_ok,
        semantic_ok=semantic_ok,errors=errors,passed=passed,cases=cases,totals=totals,buckets=buckets,
        process_cpu_ms=((after.ru_utime-before.ru_utime)+(after.ru_stime-before.ru_stime))*1000)
    (dest/'result.json').write_text(json.dumps(row,indent=2)+'\n');(dest/'runtime.json').write_text(json.dumps(loaded,indent=2)+'\n')
    records.append(row);(OUT/'results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(dict(index=index,side=side,mode=mode,passed=passed,errors=errors)),flush=True)
    assert passed,dest
assert all(sha(p)==d for p,d in hashes.items())
assert not subprocess.check_output(['git','diff','--binary','HEAD'],cwd=PRODUCT)
(OUT/'identity-final.json').write_text(json.dumps(dict(verified=True,hashes=hashes),indent=2)+'\n')
(OUT/'running.json').write_text(json.dumps(dict(state='complete',processes=len(records)))+'\n')
print('68 processes complete.',flush=True)
