// Diagnostic derivative only. No locks, allocation or per-event records in scopes.
#include "net_observer.h"
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <mutex>
#include <pthread.h>
#include <mach/mach.h>
#ifdef BR1_NET_CURRENT
#include "pagestore/KisPageStoreReclamation_p.h"
#endif
namespace {
constexpr int Roles=5, Buckets=64, Depth=32;
struct Counter {
    std::atomic<const char *> name{nullptr};
    std::atomic<unsigned long long> count{0},cpu{0},self{0};
};
struct Value { const char *name=nullptr; unsigned long long count=0,cpu=0,self=0; };
struct Frame { Counter *counter; unsigned long long start,child; };
struct Bank {
    Counter values[Buckets]{};
    Frame stack[Depth]{};
    std::atomic<int> active{0};
    std::atomic<mach_port_t> port{MACH_PORT_NULL};
    std::atomic<int> size{0};
};
Bank banks[Roles];
thread_local int role=0;
std::atomic<bool> recording{false};
std::atomic<int> errors{0};
int caseId=-1;
unsigned long long threadStarts[Roles]{}, processStart=0, foregroundStart=0;
Value starts[Roles][Buckets]{};
Value value(const Counter &c) { return {c.name.load(),c.count.load(),c.cpu.load(),c.self.load()}; }
std::mutex registry;
unsigned long long finishedCpu[Roles]{};
const int mode=[] { const char *v=std::getenv("BR1_COST_MODE"); return v?std::atoi(v):0; }();
unsigned long long clockNs(clockid_t id) {
    timespec t{}; if(clock_gettime(id,&t)) std::abort();
    return static_cast<unsigned long long>(t.tv_sec)*1000000000ULL+t.tv_nsec;
}
unsigned long long liveThreadNs(int r) {
    auto port=banks[r].port.load(); if(port==MACH_PORT_NULL) return 0;
    thread_basic_info_data_t info{}; mach_msg_type_number_t n=THREAD_BASIC_INFO_COUNT;
    if(thread_info(port,THREAD_BASIC_INFO,reinterpret_cast<thread_info_t>(&info),&n)!=KERN_SUCCESS) {
        ++errors; return 0;
    }
    return (static_cast<unsigned long long>(info.user_time.seconds)+info.system_time.seconds)*1000000000ULL+
        (static_cast<unsigned long long>(info.user_time.microseconds)+info.system_time.microseconds)*1000ULL;
}
unsigned long long threadNs(int r) {
    std::lock_guard<std::mutex> lock(registry);
    return finishedCpu[r]+liveThreadNs(r);
}
}
extern "C" void br1_net_role(int r) {
    std::lock_guard<std::mutex> lock(registry);
    if(r<0||r>=Roles) std::abort();
    role=r;
    auto port=pthread_mach_thread_np(pthread_self());
    auto old=banks[r].port.exchange(port);
    if(old!=MACH_PORT_NULL && old!=port) std::abort();
}
extern "C" void br1_net_role_end() {
    std::lock_guard<std::mutex> lock(registry);
    finishedCpu[role]+=liveThreadNs(role);
    banks[role].port.store(MACH_PORT_NULL);
}
extern "C" void *br1_net_enter(const char *name) {
    if(!mode || mode==3 || !recording.load(std::memory_order_relaxed)) return nullptr;
    Bank &b=banks[role];
    int size=b.size.load(std::memory_order_relaxed);
    int i=0; for(;i<size;++i) if(b.values[i].name.load()==name || !std::strcmp(b.values[i].name.load(),name)) break;
    if(i==size) { if(size==Buckets) {++errors;return nullptr;} b.values[i].name.store(name); b.size.store(size+1); }
    int d=b.active.load(std::memory_order_relaxed);
    if(d==Depth) {++errors;return nullptr;}
    Frame &f=b.stack[d]; f.counter=&b.values[i]; f.child=0;
    b.active.store(d+1,std::memory_order_relaxed);
    f.start=clockNs(CLOCK_THREAD_CPUTIME_ID);
    return &f;
}
extern "C" void br1_net_exit(void *handle) {
    if(!handle) return;
    const auto end=clockNs(CLOCK_THREAD_CPUTIME_ID);
    Bank &b=banks[role]; int d=b.active.load(std::memory_order_relaxed);
    auto &f=*static_cast<Frame *>(handle);
    if(d<=0 || &b.stack[d-1]!=&f || end<f.start || end-f.start<f.child) std::abort();
    auto elapsed=end-f.start;
    f.counter->count.fetch_add(1,std::memory_order_relaxed);
    f.counter->cpu.fetch_add(elapsed,std::memory_order_relaxed);
    f.counter->self.fetch_add(elapsed-f.child,std::memory_order_relaxed);
    if(d>1) b.stack[d-2].child+=elapsed;
    b.active.store(d-1,std::memory_order_release);
}
extern "C" void br1_net_begin(int id) {
    recording.store(false);
    br1_net_role(0); caseId=id;
    errors.store(0);
    for(int r=0;r<Roles;++r) {
        if(banks[r].active.load()) std::abort();
        for(int i=0;i<Buckets;++i) starts[r][i]=value(banks[r].values[i]);
        threadStarts[r]=threadNs(r);
    }
    recording.store(true);
    foregroundStart=clockNs(CLOCK_THREAD_CPUTIME_ID);
    processStart=clockNs(CLOCK_PROCESS_CPUTIME_ID);
}
extern "C" void br1_net_drain() {
#ifdef BR1_NET_CURRENT
    kisDrainPageStoreReclamation();
#endif
}
extern "C" void br1_net_end() {
    const auto processEnd=clockNs(CLOCK_PROCESS_CPUTIME_ID);
    const auto foregroundEnd=clockNs(CLOCK_THREAD_CPUTIME_ID);
    recording.store(false);
    unsigned long long totals[Roles]{};
    for(int r=0;r<Roles;++r) {
        if(banks[r].active.load()) {++errors; continue;}
        const auto end=threadNs(r);
        if(end<threadStarts[r]) ++errors;
        else totals[r]=end-threadStarts[r];
    }
    std::fprintf(stderr,"BR1_NET_TOTAL {\"case\":%d,\"mode\":%d,\"process_ns\":%llu,\"foreground_ns\":%llu,\"roles_ns\":[%llu,%llu,%llu,%llu,%llu],\"errors\":%d}\n",
        caseId,mode,processEnd-processStart,foregroundEnd-foregroundStart,
        totals[0],totals[1],totals[2],totals[3],totals[4],errors.load());
    if(errors.load()) std::abort();
    for(int r=0;r<Roles;++r) for(int i=0;i<banks[r].size.load();++i) {
        auto v=value(banks[r].values[i]);
        v.count-=starts[r][i].count; v.cpu-=starts[r][i].cpu; v.self-=starts[r][i].self;
        if(!v.count) continue;
        std::fprintf(stderr,"BR1_NET_BUCKET {\"case\":%d,\"role\":%d,\"name\":\"%s\",\"count\":%llu,\"cpu_ns\":%llu,\"self_ns\":%llu}\n",
            caseId,r,v.name,v.count,v.cpu,v.self);
    }
}

extern "C" void br1_net_count(const char *name) {
    if(mode!=3 || !recording.load(std::memory_order_relaxed)) return;
    Bank &b=banks[role];int size=b.size.load(std::memory_order_relaxed);
    int i=0;for(;i<size;++i) if(b.values[i].name.load()==name || !std::strcmp(b.values[i].name.load(),name)) break;
    if(i==size) { if(size==Buckets) std::abort();b.values[i].name.store(name);b.size.store(size+1); }
    b.values[i].count.fetch_add(1,std::memory_order_relaxed);
}
