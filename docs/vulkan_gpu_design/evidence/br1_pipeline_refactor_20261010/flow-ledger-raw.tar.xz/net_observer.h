#pragma once
#include <cstdint>
extern "C" {
__attribute__((visibility("default"))) void br1_net_role(int);
__attribute__((visibility("default"))) void br1_net_role_end();
__attribute__((visibility("default"))) void *br1_net_enter(const char *);
__attribute__((visibility("default"))) void br1_net_exit(void *);
__attribute__((visibility("default"))) void br1_net_begin(int);
__attribute__((visibility("default"))) void br1_net_end();
__attribute__((visibility("default"))) void br1_net_drain();
}
struct Br1NetThread {
    explicit Br1NetThread(int role) { br1_net_role(role); }
    ~Br1NetThread() { br1_net_role_end(); }
};
struct Br1NetScope {
    void *handle;
    explicit Br1NetScope(const char *name):handle(br1_net_enter(name)) {}
    ~Br1NetScope() { br1_net_exit(handle); }
    Br1NetScope(const Br1NetScope &)=delete;
    Br1NetScope &operator=(const Br1NetScope &)=delete;
};
