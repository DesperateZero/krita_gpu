#!/usr/bin/env python3
import hashlib,json,tarfile
from pathlib import Path
H=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (H/'raw.tar.xz').exists()
files=sorted(p for p in H.rglob('*') if p.is_file() and not p.is_symlink() and p.name not in ['raw-manifest.json','EVIDENCE.json','raw.tar.xz','freeze-run.log'] and '__pycache__' not in p.parts)
manifest={str(p.relative_to(H)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in files}
(H/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(H/'raw.tar.xz','w:xz',preset=1) as archive:
 for p in files:archive.add(p,arcname=str(p.relative_to(H)),recursive=False)
 archive.add(H/'raw-manifest.json',arcname='raw-manifest.json')
with tarfile.open(H/'raw.tar.xz') as archive:
 for name,record in manifest.items():
  data=archive.extractfile(name).read();assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
result={'files':len(files),'archive_bytes':(H/'raw.tar.xz').stat().st_size,'archive_sha256':sha(H/'raw.tar.xz'),'manifest_sha256':sha(H/'raw-manifest.json'),'all_archive_members_verified':True,'verification_sha256':sha(H/'verification.json')}
(H/'EVIDENCE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
