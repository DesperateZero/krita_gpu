#include "observe.h"
#include <atomic>
#include <cstdio>
namespace {std::atomic<unsigned> stage{0}; std::atomic<std::uint64_t> counts[6][12]{}; thread_local bool inside=false;}
void br1_note(unsigned i,std::uint64_t n){if(inside)counts[stage.load(std::memory_order_relaxed)%6][i].fetch_add(n,std::memory_order_relaxed);}
Br1Scope::Br1Scope():previous(inside){inside=true;br1_note(0);}
Br1Scope::~Br1Scope(){inside=previous;}
extern "C" __attribute__((visibility("default"))) void br1_cost_stage(int n){stage.store(n,std::memory_order_relaxed);}
extern "C" __attribute__((visibility("default"))) void br1_cost_dump(){for(unsigned s=0;s<6;++s){std::fprintf(stderr,"BR1_BOUNDARY_COUNT {\"stage\":%u,\"values\":[",s);for(unsigned i=0;i<12;++i)std::fprintf(stderr,"%s%llu",i?",":"",(unsigned long long)counts[s][i].load());std::fprintf(stderr,"]}\n");}}
