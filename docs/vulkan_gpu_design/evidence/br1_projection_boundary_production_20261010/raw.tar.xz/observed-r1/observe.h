#pragma once
#include <cstdint>
void br1_note(unsigned, std::uint64_t=1);
struct Br1Scope {bool previous; Br1Scope(); ~Br1Scope();};
